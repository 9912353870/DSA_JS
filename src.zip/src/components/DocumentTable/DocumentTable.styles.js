const styles = (theme) => ({
  noDocuments: {
    padding: theme.spacing(1.5),
  },
});

export default styles;
