import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { firstBy } from 'thenby';
import merge from 'lodash/merge';

// app
import { DmsGxbDocumentsTableView } from './DmsGxbDocumentsTable.view';
import * as utils from 'utils';
import {
  getViewTableDocuments,
  linkMultipleDmsDocuments,
  selectDmsFileViewGridDataLoader,
  selectorDmsViewFiles,
  showModal,
  hideModal,
  viewDocumentsDownload,
  viewDocumentsMultiDownload,
} from 'stores';
import * as constants from 'consts';
import { usePagination } from 'hooks';

// mui
import { Box, Typography } from '@material-ui/core';

DmsGxbDocumentsTable.propTypes = {
  gxbOptions: PropTypes.shape({
    referenceId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    sectionType: PropTypes.oneOf(['Claim', 'Loss', 'Policy', 'Task', 'Case', 'Processing Instruction']).isRequired,
    documentTypeKey: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    instructionId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    linkReferenceId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    linkSectionType: PropTypes.oneOf(['Claim', 'Loss', 'Policy', 'Task', 'Case', 'Processing Instruction']).isRequired,
    canLink: PropTypes.bool,
    canMultiSelect: PropTypes.bool,
    canSearch: PropTypes.bool,
    showHeader: PropTypes.bool,
  }),
};

export default function DmsGxbDocumentsTable({ gxbOptions }) {
  const dispatch = useDispatch();

  const gxbOptionsMerged = merge(
    {
      showHeader: true,
      canSearch: true,
      canMultiSelect: true,
      canLink: true,
    },
    gxbOptions
  );

  //selectors
  const viewDocumentList = useSelector(selectorDmsViewFiles);
  const dmsFileViewGridDataLoading = useSelector(selectDmsFileViewGridDataLoader);

  // state
  const [search, setSearch] = useState('');
  const [resetKey, setResetKey] = useState();
  const [originalTableData, setOriginalTableData] = useState([]);
  const [filteredTableData, setFilteredTableData] = useState([]);
  const [searchIndex, setSearchIndex] = useState([]);
  const [selectedDocs, setSelectedDocs] = useState([]);
  const [newPage, setNewPage] = useState(constants.DMS_PAGINATION_DEFAULT_PAGE);
  const [rowsPerPage, setRowsPerPage] = useState(constants.DMS_DEFAULT_ROWS_PER_PAGE);
  const [isDmsFileViewGridDataLoading, setIsDmsFileViewGridDataLoading] = useState(dmsFileViewGridDataLoading);

  // constants
  const isAllSelectedDocsAreLinked = selectedDocs?.every((doc) => Boolean(doc?.isLinked));
  const docClassification = utils?.dmsFormatter?.getDocumentClassificationList();
  const docClassificationList = new Map(
    docClassification?.map((item) => {
      return [item?.id, item?.value];
    })
  );
  const cols = [
    {
      id: 'multiSelect',
      visible: true,
    },
    { id: 'documentName', label: utils.string.t('dms.view.columns.documentName'), sort: { type: 'lexical', direction: 'asc' } },
    { id: 'documentSource', label: utils.string.t('dms.view.columns.documentSource'), sort: { type: 'lexical', direction: 'asc' } },
    { id: 'documentTypeDescription', label: utils.string.t('dms.view.columns.documentType'), sort: { type: 'lexical', direction: 'asc' } },
    {
      id: 'docClassification',
      label: utils.string.t('dms.view.columns.documentClassification'),
      sort: { type: 'lexical', direction: 'asc' },
    },
    { id: 'updatedDate', label: utils.string.t('dms.view.columns.uploadedDate'), sort: { type: 'date', direction: 'asc' } },
    { id: 'createdByName', label: utils.string.t('dms.view.columns.uploadedBy'), sort: { type: 'lexical', direction: 'asc' } },
    {
      id: 'documentVersion',
      label: utils.string.t('dms.view.columns.documentVersion'),
      sort: { type: 'lexical', direction: 'asc' },
    },
    {
      id: 'createdDate',
      label: utils.string.t('dms.view.columns.creationDate'),
      sort: { type: 'date', direction: 'asc' },
      visible: true,
    },
    {
      id: 'link',
      visible: true,
    },
    { id: 'actions', menu: true, visible: true },
  ];

  const popoverActions = [
    {
      id: 'download',
      label: utils.string.t('dms.view.popOverMenuItems.download'),
      callback: ({ doc }) => dispatch(viewDocumentsDownload(doc)),
    },
    {
      id: 'versionHistory',
      label: utils.string.t('dms.view.popOverMenuItems.versionHistory'),
      callback: ({ doc }) => showVersionHistoryModal(doc),
    },
  ];

  // handlers
  const getAllGxbDocuments = () => {
    dispatch(
      getViewTableDocuments({
        referenceId: gxbOptions?.referenceId,
        sectionType: gxbOptions?.sectionType,
        documentTypeKey: gxbOptions?.documentTypeKey,
        instructionId: gxbOptions?.instructionId,
        isGxbDocuments: true,
      })
    );
  };

  const getConfirmMessage = (linkedDocs, unlinkedDocs) =>
    utils.generic.isValidArray(linkedDocs, true) ? (
      <Box>
        <Typography>{`${utils.string.t('dms.gxbDocuments.existingLinkedDocuments')}:`}</Typography>
        <ul>
          {linkedDocs?.map((doc) => (
            <li key={doc.documentId}>{doc?.documentName}</li>
          ))}
        </ul>
        {utils.generic.isValidArray(unlinkedDocs, true) && (
          <Typography>{utils.string.t('dms.gxbDocuments.confirmMessageExistingLinkedDocuments')}</Typography>
        )}
      </Box>
    ) : (
      <Box>
        <Typography>{utils.string.t('dms.gxbDocuments.confirmMessage')}</Typography>
      </Box>
    );

  const confirmDocumentlink = (docs) => {
    const linkedDocs = docs?.filter((doc) => Boolean(doc?.isLinked)) || [];
    const unlinkedDocs = docs?.filter((doc) => !Boolean(doc?.isLinked)) || [];
    const requestParams = unlinkedDocs?.map((d) => {
      return {
        documentId: d?.documentId,
        referenceId: gxbOptions?.linkReferenceId,
        sectionType: gxbOptions?.linkSectionType,
      };
    });

    dispatch(
      showModal({
        component: 'CONFIRM',
        props: {
          fullWidth: true,
          title: utils.string.t('dms.gxbDocuments.title'),
          maxWidth: 'xs',
          componentProps: {
            confirmLabel: utils.generic.isValidArray(unlinkedDocs, true)
              ? utils.string.t('dms.gxbDocuments.confirmLabel')
              : utils.string.t('app.ok'),
            hideCancelButton: !utils.generic.isValidArray(unlinkedDocs, true),
            confirmMessage: getConfirmMessage(linkedDocs, unlinkedDocs),
            submitHandler: () => {
              if (utils.generic.isValidArray(unlinkedDocs, true)) {
                dispatch(linkMultipleDmsDocuments(requestParams)).then((response) => {
                  if (response?.status === constants.API_RESPONSE_OK) {
                    resetToDefaultValues();
                  }
                });
              } else {
                dispatch(hideModal('CONFIRM'));
              }
            },
          },
        },
      })
    );
  };

  const handleLinkFile = (file) => {
    if (file.isLinked) {
      return;
    }
    confirmDocumentlink([file]);
  };

  const resetToDefaultValues = () => {
    getAllGxbDocuments();
    setSelectedDocs([]);
  };

  const handleChangePage = (newPage) => {
    setNewPage(newPage);
  };

  const handleChangeRowsPerPage = (rowsPerPage) => {
    setNewPage(constants.DMS_PAGINATION_DEFAULT_PAGE);
    setRowsPerPage(rowsPerPage);
  };

  const showVersionHistoryModal = (docData) => {
    dispatch(
      showModal({
        component: 'DMS_VERSION_HISTORY',
        props: {
          fullWidth: true,
          title: utils.string.t('dms.view.versionHistory.title'),
          maxWidth: 'xs',
          componentProps: {
            docData: docData,
          },
        },
      })
    );
  };

  const resetSearch = () => {
    setResetKey(new Date().getTime());
    setSearch('');
  };

  const submitSearch = (query) => {
    setSearch(query);
  };

  const handleSort = (by, dir) => {
    originalTableData?.sort(firstBy(utils.sort.array('lexical', by, dir)));
  };

  const handleCheckboxClick = (e, doc) => {
    e.stopPropagation();
    let newlySelectedDocs = [...selectedDocs, doc];
    if (selectedDocs?.find((docs) => docs.documentId === doc.documentId)) {
      newlySelectedDocs = newlySelectedDocs.filter((selectedDoc) => selectedDoc.documentId !== doc.documentId);
    }
    setSelectedDocs(newlySelectedDocs);
  };

  const handleMultipleDownload = () => {
    const selectedDocIds = selectedDocs?.map((docId) => docId.documentId);
    if (selectedDocs?.length !== 1) {
      dispatch(viewDocumentsMultiDownload(selectedDocIds));
      return;
    }
    dispatch(viewDocumentsDownload(selectedDocs?.[0]));
  };

  const handleMutipleLink = () => {
    confirmDocumentlink(selectedDocs);
  };

  const getDocClassification = (value) => {
    return docClassificationList?.get(Number(value));
  };

  // Hooks
  const pagination = usePagination(
    filteredTableData || [],
    {
      page: newPage || constants.DMS_PAGINATION_DEFAULT_PAGE,
      rowsTotal: originalTableData.length || 0,
      rowsPerPage: rowsPerPage,
    },
    handleChangePage,
    handleChangeRowsPerPage
  );

  // Effects
  useEffect(() => {
    utils.dms.resetDmsFiles(dispatch);
    getAllGxbDocuments();
    // Cleanup
    return () => {
      utils.dms.resetDmsFiles(dispatch);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setIsDmsFileViewGridDataLoading(dmsFileViewGridDataLoading);
  }, [dmsFileViewGridDataLoading]);

  useEffect(() => {
    const tableDataString = (data, allValues) => {
      if (!allValues) allValues = [];
      for (const key in data) {
        if (typeof data[key] === 'object') tableDataString(data[key], allValues);
        else allValues.push(`${data[key]}' '`);
      }
      return allValues;
    };

    const setInitialTableData = () => {
      setOriginalTableData(viewDocumentList);
      setFilteredTableData(viewDocumentList);
      const searchInd = viewDocumentList?.map((data) => {
        const allValues = tableDataString(data);
        return { allValues: allValues.toString() };
      });
      setSearchIndex(searchInd);
    };

    setInitialTableData();
  }, [viewDocumentList]);

  useEffect(() => {
    if (search) {
      const newFilteredTableData = searchIndex?.map((data, index) => {
        if (data?.allValues?.toLowerCase().indexOf(search.toLowerCase()) >= 0) return originalTableData[index];
        return null;
      });
      setFilteredTableData(
        newFilteredTableData?.filter((data) => {
          if (data) return true;
          return false;
        })
      );
    } else setFilteredTableData(originalTableData);
  }, [search, originalTableData, searchIndex]);

  useEffect(() => {
    setFilteredTableData(originalTableData?.slice(newPage * rowsPerPage, newPage * rowsPerPage + rowsPerPage));
  }, [newPage, rowsPerPage, originalTableData]);

  // abort
  if (!viewDocumentList) return null;

  return (
    <DmsGxbDocumentsTableView
      cols={cols}
      sort={{
        by: 'documentName',
        type: 'lexical',
        direction: 'desc',
      }}
      documents={filteredTableData}
      popoverActions={popoverActions}
      search={search}
      resetKey={resetKey}
      showHeader={gxbOptionsMerged.showHeader}
      canSearch={gxbOptionsMerged.canSearch}
      canMultiSelect={gxbOptionsMerged.canMultiSelect}
      canLink={gxbOptionsMerged.canLink}
      selectedDocs={selectedDocs}
      isDmsFileViewGridDataLoading={isDmsFileViewGridDataLoading}
      pagination={pagination}
      isAllSelectedDocsAreLinked={isAllSelectedDocsAreLinked}
      handlers={{
        link: handleLinkFile,
        getDocClassification: getDocClassification,
        handleCheckboxClick: handleCheckboxClick,
        handleMultipleDownload: handleMultipleDownload,
        handleMutipleLink: handleMutipleLink,
        handleSort: handleSort,
        resetSearch: resetSearch,
        submitSearch: submitSearch,
      }}
    />
  );
}
