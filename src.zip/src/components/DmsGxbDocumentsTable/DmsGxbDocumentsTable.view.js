import React from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';

// app
import styles from './DmsGxbDocumentsTable.styles';
import {
  Avatar,
  Button,
  Link,
  Pagination,
  Search,
  Skeleton,
  TableHead,
  TableCell,
  TableToolbar,
  TableActions,
  PopoverMenu,
  Warning,
} from 'components';
import { useSort, useMedia } from 'hooks';
import * as utils from 'utils';
import config from 'config';

// mui
import { Box, Checkbox, makeStyles, Table, TableBody, TableContainer, TableRow, Typography } from '@material-ui/core';
import CloudDownloadOutlined from '@material-ui/icons/CloudDownloadOutlined';
import DescriptionIcon from '@material-ui/icons/Description';
import InsertDriveFileIcon from '@material-ui/icons/InsertDriveFile';
import LinkIcon from '@material-ui/icons/Link';
import LinkOffOutlinedIcon from '@material-ui/icons/LinkOffOutlined';
import LinkOutlinedIcon from '@material-ui/icons/LinkOutlined';

DmsGxbDocumentsTableView.propTypes = {
  cols: PropTypes.array.isRequired,
  sort: PropTypes.object.isRequired,
  documents: PropTypes.array.isRequired,
  popoverActions: PropTypes.array.isRequired,
  search: PropTypes.string.isRequired,
  resetKey: PropTypes.number,
  selectedDocs: PropTypes.array.isRequired,
  showHeader: PropTypes.bool.isRequired,
  canSearch: PropTypes.bool.isRequired,
  canMultiSelect: PropTypes.bool.isRequired,
  canLink: PropTypes.bool.isRequired,
  isDmsFileViewGridDataLoading: PropTypes.bool.isRequired,
  isAllSelectedDocsAreLinked: PropTypes.bool.isRequired,
  handlers: PropTypes.shape({
    link: PropTypes.func.isRequired,
    getDocClassification: PropTypes.func.isRequired,
    handleCheckboxClick: PropTypes.func.isRequired,
    handleMultipleDownload: PropTypes.func.isRequired,
    handleMutipleLink: PropTypes.func.isRequired,
    handleSort: PropTypes.func.isRequired,
    resetSearch: PropTypes.func.isRequired,
    submitSearch: PropTypes.func.isRequired,
  }).isRequired,
  pagination: PropTypes.shape({
    obj: PropTypes.object.isRequired,
    handlers: PropTypes.shape({
      handleChangePage: PropTypes.func.isRequired,
      handleChangeRowsPerPage: PropTypes.func.isRequired,
    }).isRequired,
  }).isRequired,
};

export function DmsGxbDocumentsTableView({
  cols: colsArr,
  sort: sortObj,
  documents,
  popoverActions,
  search,
  resetKey,
  selectedDocs,
  showHeader,
  canSearch,
  canMultiSelect,
  canLink,
  isDmsFileViewGridDataLoading,
  pagination,
  isAllSelectedDocsAreLinked,
  handlers,
}) {
  const media = useMedia();
  const classes = makeStyles(styles, { name: 'DmsGxbDocumentsTable' })({ isMobile: media.mobile });

  const { cols, sort } = useSort(colsArr, sortObj, handlers.handleSort);

  const hasNoDocument = documents?.length === 0;
  const selectedDocLength = selectedDocs?.length;
  const hasNoDocumentSelected = selectedDocLength === 0;

  const TableActionsComponent = (
    <TableActions>
      {showHeader && (
        <Box display="flex" alignItems="center">
          <Box className={classes.icon}>
            <DescriptionIcon />
          </Box>
          <Typography variant="body2" className={classes.title}>
            {utils.string.t('dms.view.documents.title')}
          </Typography>
        </Box>
      )}
    </TableActions>
  );

  const SearchComponent = (
    <Search
      key={resetKey}
      text={search || ''}
      placeholder={utils.string.t('dms.view.searchDocuments')}
      minChars={4}
      submitButtonProps={{ size: 'small' }}
      nestedClasses={{
        inputPropsRoot: classes.inputPropsRoot,
      }}
      handlers={{
        search: (args) => {
          handlers.submitSearch(args);
        },
        reset: () => {
          handlers.resetSearch();
        },
      }}
    />
  );

  return (
    <Box mt={2}>
      <Box>
        <TableToolbar>
          {TableActionsComponent}
          {canSearch && SearchComponent}
        </TableToolbar>
      </Box>

      <TableContainer>
        <Table size="small">
          <TableHead columns={cols} sorting={sort} />
          <TableBody>
            {isDmsFileViewGridDataLoading ? (
              <TableRow>
                <TableCell colSpan={cols.length}>
                  <Skeleton height={40} animation="wave" displayNumber={5} />
                </TableCell>
              </TableRow>
            ) : (
              utils.generic.isValidArray(documents, true) &&
              documents?.map((doc) => {
                const checked =
                  utils.generic.isValidArray(selectedDocs, true) &&
                  selectedDocs?.map((selDoc) => selDoc.documentId).includes(doc.documentId);
                return (
                  <TableRow key={doc?.documentId}>
                    <TableCell compact minimal>
                      {canMultiSelect && (
                        <Checkbox color="primary" checked={checked} onClick={(e) => handlers.handleCheckboxClick(e, doc)} />
                      )}
                    </TableCell>
                    <TableCell>
                      <Link
                        target="_blank"
                        href={`${window.location.origin}/document/${doc?.documentId}/${doc?.documentName}`}
                        rel="noopener"
                        nestedClasses={{
                          link: classes.link,
                        }}
                        color="secondary"
                        tooltip={{ title: utils.string.t('dms.view.documentTooltip') }}
                        text={doc?.documentName}
                      />
                      <Box display={'flex'} alignItems={'center'}>
                        {Boolean(Number(doc?.isUploadedOnGxb)) && (
                          <Box display={'flex'} alignItems={'center'}>
                            <Avatar size={20} border={false} avatarClasses={classes.fileIconColor} icon={InsertDriveFileIcon} />
                            <Typography className={classes.fileNameSize}>{utils.string.t('dms.view.gxb')}</Typography>
                          </Box>
                        )}
                        {Boolean(doc?.isLinked) && <Button size="small" variant="text" icon={LinkOutlinedIcon} disabled />}
                      </Box>
                    </TableCell>
                    <TableCell>{doc?.srcApplication?.toUpperCase()}</TableCell>
                    <TableCell>{doc?.documentTypeDescription}</TableCell>
                    <TableCell>{handlers.getDocClassification(doc?.docClassification)}</TableCell>
                    <TableCell>
                      {utils.string.t('format.date', { value: { date: doc?.updatedDate, format: config.ui.format.date.text } })}
                    </TableCell>
                    <TableCell>{doc?.createdByName}</TableCell>
                    <TableCell>{doc?.documentVersion}</TableCell>
                    <TableCell>
                      {utils.string.t('format.date', { value: { date: doc?.createdDate, format: config.ui.format.date.text } })}
                    </TableCell>
                    {canLink && (
                      <TableCell>
                        <Button
                          size="small"
                          variant="text"
                          tooltip={{ title: utils.string.t('dms.view.popOverMenuItems.link') }}
                          disabled={Boolean(doc?.isLinked)}
                          icon={!doc?.isLinked ? LinkOutlinedIcon : LinkOffOutlinedIcon}
                          onClick={() => handlers.link(doc)}
                        />
                      </TableCell>
                    )}
                    <TableCell>
                      <PopoverMenu id="view-menu-list" items={popoverActions} data={{ doc }} />
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
        {!isDmsFileViewGridDataLoading && hasNoDocument && (
          <Box p={5}>
            <Warning text={utils.string.t('dms.view.gridDataEmptyWarning')} type="info" align="center" size="large" icon />
          </Box>
        )}
      </TableContainer>

      {utils.generic.isValidArray(documents, true) && (
        <Pagination
          page={get(pagination, 'obj.page')}
          count={get(pagination, 'obj.rowsTotal')}
          rowsPerPage={get(pagination, 'obj.rowsPerPage')}
          onChangePage={get(pagination, 'handlers.handleChangePage')}
          onChangeRowsPerPage={get(pagination, 'handlers.handleChangeRowsPerPage')}
        />
      )}

      {canMultiSelect && !hasNoDocument && (
        <>
          <Box className={classes.multiSelectContainer}>
            <Box display="flex" flexDirection="column">
              <Box display="flex">
                <Box mr={1}>
                  <Button
                    icon={CloudDownloadOutlined}
                    iconWide
                    text={utils.string.t('dms.view.buttons.download')}
                    color="primary"
                    variant="outlined"
                    size="xsmall"
                    disabled={hasNoDocument || hasNoDocumentSelected}
                    onClick={() => handlers.handleMultipleDownload()}
                  />
                </Box>
                {canLink && (
                  <Box mr={1}>
                    <Button
                      icon={LinkIcon}
                      text={utils.string.t('dms.view.buttons.link')}
                      color="primary"
                      variant="outlined"
                      size="xsmall"
                      disabled={isAllSelectedDocsAreLinked || hasNoDocument || hasNoDocumentSelected}
                      onClick={() => handlers.handleMutipleLink()}
                    />
                  </Box>
                )}
              </Box>
              <Box display="flex" alignItems="center" mt={0.5}>
                <Typography variant="body2">
                  {utils.string.t('dms.view.selectedDoc', {
                    count: selectedDocLength,
                  })}
                </Typography>
              </Box>
            </Box>
          </Box>
        </>
      )}
    </Box>
  );
}
