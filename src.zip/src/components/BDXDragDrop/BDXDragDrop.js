import React, { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { useDropzone } from 'react-dropzone';
import { Controller } from 'react-hook-form';

// app
import * as utils from 'utils';
import styles from './BDXDragDrop.styles';
import { ErrorMessage, Button } from 'components';

// mui
import { makeStyles, Grid } from '@material-ui/core';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import DeleteIcon from '@material-ui/icons/Delete';
import { ReactComponent as ExcelLogo } from 'assets/svg/excel_icon.svg';

BDXDragDrop.propTypes = {
  name: PropTypes.string.isRequired,
  control: PropTypes.object.isRequired,
  onChange: PropTypes.func.isRequired,
  label: PropTypes.string,
  dragLabel: PropTypes.string,
  hint: PropTypes.string,
  error: PropTypes.object,
  showUploadPreview: PropTypes.bool,
  fileNameLength: PropTypes.number,
};

BDXDragDrop.defaultProps = {
  showUploadPreview: true,
  fileNameLength: 48,
};

export function BDXDragDrop({ name, label, hint, control, onChange, dragLabel, showUploadPreview, fileNameLength, defaultFile }) {
  const classes = makeStyles(styles, { name: 'BDXDragDrop' })();
  const [uploadedFile, setUploadedFile] = useState({});
  const [error, setError] = useState();
  const validTypes = ['.csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];

  const onDrop = useCallback(
    (file) => {
      if (file && file.length > 0) {
        if (validTypes.includes(file[0].type)) {
          var reader = new FileReader();
          reader.onload = function (e) {
            var contents = e.target.result;
            onChange(contents, file);
          };

          reader.readAsArrayBuffer(file[0]);
          setUploadedFile(file[0]);
          setError({});
        } else {
          onRemove();
          setError({ message: utils.string.t('notification.bdx.fileError') });
        }
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [uploadedFile]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  const isEmpty = (obj) => Object.keys(obj).length === 0;

  const onRemove = () => {
    setUploadedFile({});
    onChange(null);
  };

  const UploadedFile = ({ file }) => {
    return (
      <div className={classes.uploadedFile} data-testid="uploadedFile">
        <div className={classes.uploadedFileListLabel}>
          <CheckCircleIcon className={classes.successIcon} />
          <p>{utils.file.truncate(file.name, fileNameLength)}</p>

          <Button icon={DeleteIcon} size="xsmall" variant="text" style={{ color: '#E93D4C' }} onClick={() => onRemove()} />
        </div>
      </div>
    );
  };

  const dragInstruction = (
    <>
      <CloudUploadIcon className={classes.uploadIcon} />
      <p className={classes.dragFile}>{dragLabel || utils.string.t('form.dragDrop.dragBDXHere')}</p>
      <p className={classes.browseFile}>
        <ExcelLogo className={classes.excelIcon} />
        {utils.string.t('form.dragDrop.chooseFile')}
      </p>
    </>
  );

  return (
    <div className={classes.root}>
      <Grid container spacing={4}>
        <Grid item>
          <label className={classes.formLabel} data-testid="bdxdragdrop-label">
            {label}
          </label>
          {control ? (
            <Controller
              control={control}
              name={name}
              as={
                <div
                  className={isDragActive ? `${classes.dragOver} ${classes.dragArea} ` : `${classes.dragArea}`}
                  {...getRootProps()}
                  data-form-type="file"
                >
                  <input {...getInputProps()} data-testid="bdxDropZone" />
                  {dragInstruction}
                </div>
              }
            />
          ) : (
            <div className={classes.dragArea} {...getRootProps()} data-form-type="file">
              <input {...getInputProps()} data-testid="bdxDropZone" />
              {dragInstruction}
            </div>
          )}
        </Grid>

        <Grid item>
          {(defaultFile?.length > 0 && <UploadedFile file={defaultFile[0]} />) ||
            (showUploadPreview && uploadedFile && !isEmpty(uploadedFile) && <UploadedFile file={uploadedFile} />)}
        </Grid>
      </Grid>
      <ErrorMessage error={error} hint={hint} />
    </div>
  );
}

export default BDXDragDrop;
