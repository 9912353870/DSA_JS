import React from 'react';

// app
import { BDXDragDrop } from './BDXDragDrop';
import { render, waitFor, act } from 'tests';
import userEvent from '@testing-library/user-event';

describe('COMPONENTS › BDXDragDrop', () => {
  const defaultProps = {
    name: 'file',
    label: 'BDX File',
    dragLabel: 'Drag and Drop here',
    showUploadPreview: true,
    onChange: jest.fn(),
  };

  it('renders with props without crashing', () => {
    // arrange
    const fakeBdx = new File(['1'], 'bdx.xlsx', { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const { getByTestId, getByText } = render(<BDXDragDrop {...defaultProps} defaultFile={fakeBdx} />);

    // assert
    expect(getByTestId('bdxdragdrop-label')).toHaveTextContent(defaultProps.label);
    expect(getByTestId('bdxDropZone')).toBeInTheDocument();
    expect(getByText('Drag and Drop here')).toBeInTheDocument();
  });

  it('enables to upload xlsx and csv files and reject other file formats', async () => {
    const { queryByTestId, getByText } = render(<BDXDragDrop {...defaultProps} />);
    const fakeBdx = new File(['1'], 'bdx.xlsx', { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const fakepdf = new File(['1'], 'bdx.pdf', { type: 'application/pdf' });

    // assert
    // form
    expect(queryByTestId('bdxDropZone')).toBeInTheDocument();
    await act(async () => {
      await waitFor(() => {
        userEvent.upload(queryByTestId('bdxDropZone'), fakeBdx);
      });
    });
    expect(queryByTestId('uploadedFile')).toBeInTheDocument();

    await act(async () => {
      await waitFor(() => {
        userEvent.upload(queryByTestId('bdxDropZone'), fakepdf);
      });
    });
    expect(queryByTestId('uploadedFile')).not.toBeInTheDocument();
    expect(getByText('notification.bdx.fileError')).toBeInTheDocument();
  });
});
