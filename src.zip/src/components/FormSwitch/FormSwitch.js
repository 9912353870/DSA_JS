import React from 'react';

// app
import { FormSwitchView } from './FormSwitch.view';

export default function FormSwitch(props) {
  return <FormSwitchView {...props} />;
}
