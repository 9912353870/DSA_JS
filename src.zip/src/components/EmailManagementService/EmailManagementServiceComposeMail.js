import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import * as Yup from 'yup';
import isEmpty from 'lodash/isEmpty';
import uniqBy from 'lodash/uniqBy';

//app
import styles from './EmailManagementService.styles';
import EmailManagementServiceComposeMailView from './EmailManagementServiceComposeMail.view';
import * as constants from 'consts';
import * as utils from 'utils';
import { MultiSelect } from 'components';
import { showModal, addLoader, getEmsExistingDocuments, resetEmsExistingDocuments, selectEmsExistingDocuments } from 'stores';

//mui
import { makeStyles } from '@material-ui/core';

EmailManagementServiceComposeMail.propTypes = {
  forwardAttachments: PropTypes.array.isRequired,
  forwardMessage: PropTypes.string.isRequired,
  forwardSubject: PropTypes.string.isRequired,
  handlers: PropTypes.shape({
    sendEmail: PropTypes.func,
  }).isRequired,
  caseDetailsObject: PropTypes.object,
  accountDetails: PropTypes.object,
  uploadOptions: PropTypes.object.isRequired,
  getEmsExistingDocumentsPayload: PropTypes.object.isRequired,
};

function EmailManagementServiceComposeMail({
  forwardAttachments,
  forwardSubject,
  forwardMessage,
  handlers,
  caseDetailsObject,
  accountDetails,
  uploadOptions,
  getEmsExistingDocumentsPayload,
}) {
  const classes = makeStyles(styles, { name: 'EmailManagementService' })();
  const dispatch = useDispatch();

  const emsExistingDocuments = useSelector(selectEmsExistingDocuments);

  const [docList, setDocList] = useState(
    utils.generic.isValidArray(emsExistingDocuments, true)
      ? emsExistingDocuments?.map((doc) => ({ id: doc?.documentId, name: doc?.documentName }))
      : []
  );

  const [attachedMailDocuments, setAttachedMailDocuments] = useState(
    utils.generic.isValidArray(forwardAttachments, true)
      ? forwardAttachments?.map((doc) => ({ id: doc?.documentId, name: doc?.documentName }))
      : []
  );

  useEffect(() => {
    dispatch(getEmsExistingDocuments(getEmsExistingDocumentsPayload));

    // cleanup
    return () => {
      dispatch(resetEmsExistingDocuments());
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setDocList((oldArray) => {
      const existingDocumentsList = emsExistingDocuments?.map((doc) => ({ id: doc?.documentId, name: doc?.documentName })) || [];
      const allDocs = [...oldArray, ...existingDocumentsList];
      return uniqBy(allDocs, 'id');
    });
  }, [emsExistingDocuments]);

  const hasAttachedDocuments = utils.generic.isValidArray(attachedMailDocuments, true);

  const yupString = Yup.string();
  const fields = [
    {
      type: 'file',
      name: 'filesUpload',
      value: null,
      showUploadPreview: false,
      showMaxFilesError: true,
      dragLabel: utils.string.t('form.dragDrop.dragFileHere'),
      showButton: false,
      componentProps: {
        multiple: constants.PROCESSING_INSTRUCTION_FILE_UPLOAD_ALLOW_MULTIPLE,
        maxFiles: constants.PROCESSING_INSTRUCTION_DETAILS_FILE_UPLOAD_MAX_FILES,
        maxSize: constants.PROCESSING_INSTRUCTION_FILE_UPLOAD_MAX_FILE_SIZE,
        accept: constants.PROCESSING_INSTRUCTION_FILE_UPLOAD_ALLOWED_FILE_EXT,
      },
    },
    {
      name: 'emailTo',
      type: 'text',
      value:
        (caseDetailsObject?.frontEndSendDocs &&
          accountDetails?.documentSentType === utils.string.t('premiumProcessing.processingClientTable.tableColumns.backOfficeToFEC') &&
          !accountDetails?.sendDate &&
          caseDetailsObject?.fecEmail) ||
        '',
      variant: 'standard',
      validation: yupString.required(utils.string.t('validation.required')).test({
        name: 'mailTo',
        test: function (value) {
          let mandatoryEmail;
          if (
            caseDetailsObject?.frontEndSendDocs &&
            accountDetails?.documentSentType === utils.string.t('premiumProcessing.processingClientTable.tableColumns.backOfficeToFEC') &&
            !accountDetails?.sendDate &&
            caseDetailsObject?.fecEmail
          ) {
            mandatoryEmail = value
              .split(';')
              .map((email) => email.trim())
              .filter((v) => !isEmpty(v))
              .find((v) => v === caseDetailsObject?.fecEmail);
          }
          const firstInvalidEmail = value
            .split(';')
            .map((email) => email.trim())
            .filter((v) => !isEmpty(v))
            .find((v) => !yupString.email().isValidSync(v));
          return firstInvalidEmail
            ? this.createError({
                message: utils.string.t('validation.inValidEmail', { firstInvalidEmail }),
              })
            : caseDetailsObject?.frontEndSendDocs &&
              accountDetails?.documentSentType === utils.string.t('premiumProcessing.processingClientTable.tableColumns.backOfficeToFEC') &&
              !accountDetails?.sendDate &&
              caseDetailsObject?.fecEmail &&
              !mandatoryEmail
            ? this.createError({
                message: utils.string.t('validation.mandatoryEmail', {
                  mandatoryEmail: caseDetailsObject?.fecEmail,
                }),
              })
            : true;
        },
      }),
      muiComponentProps: {
        fullWidth: true,
        classes: {
          root: classes.input,
        },
      },
    },
    {
      name: 'emailCc',
      type: 'text',
      value: '',
      variant: 'standard',
      validation: yupString.test({
        name: 'mailCc',
        test: function (value) {
          const firstInvalidEmail = value
            .split(';')
            .map((email) => email.trim())
            .filter((v) => !isEmpty(v))
            .find((v) => !yupString.email().isValidSync(v));

          return !firstInvalidEmail
            ? true
            : this.createError({
                message: utils.string.t('validation.inValidEmail', { firstInvalidEmail }),
              });
        },
      }),
      muiComponentProps: {
        fullWidth: true,
        classes: {
          root: classes.input,
        },
      },
    },
    {
      name: 'subject',
      type: 'text',
      value: forwardSubject || '',
      variant: 'standard',
      validation: yupString.required(utils.string.t('validation.required')),
      muiComponentProps: {
        fullWidth: true,
        classes: {
          root: classes.input,
        },
      },
    },
    {
      name: 'message',
      type: 'textarea',
      value: forwardMessage || '',
      validation: yupString.required(utils.string.t('validation.required')),
      muiComponentProps: {
        inputProps: { maxLength: 4000 },
        multiline: true,
        minRows: hasAttachedDocuments ? 8 : 13,
        maxRows: hasAttachedDocuments ? 8 : 13,
        fullWidth: true,
        classes: {
          root: classes.input,
        },
      },
    },
  ];

  const actions = [
    {
      name: 'sendMail',
      handler: (formData) =>
        handlers.sendEmail({
          ...formData,
          attachments: attachedMailDocuments?.map((doc) => ({ documentId: doc?.id, documentName: doc?.name })),
        }),
    },
  ];

  const toggleOption = (controlId, selectedDoc) => {
    setAttachedMailDocuments((oldArray) => {
      const isFileAlreadyAdded = oldArray?.some((o) => o?.id === selectedDoc?.id);
      if (isFileAlreadyAdded) {
        return oldArray.filter((item) => item.id !== selectedDoc?.id);
      }
      const newDocs = [...oldArray, selectedDoc];
      return uniqBy(newDocs, 'id');
    });
  };

  const removeSelectAllFilters = (oldArray, selectedOptions) => {
    const remainingOptions = oldArray?.filter((option) => !selectedOptions?.find((oa) => oa.id === option.id));
    return remainingOptions;
  };

  const toggleSelectAll = (field, options, isSelectAll) => {
    setAttachedMailDocuments((oldArray) => {
      const currentSelectedOptions = docList?.length === options?.length ? docList : options;
      const newOptions = isSelectAll ? [...oldArray, ...currentSelectedOptions] : removeSelectAllFilters(oldArray, currentSelectedOptions);
      return uniqBy(newOptions, 'id');
    });
  };

  const attachmentProps = {
    id: 'attachments',
    type: 'multiSelect',
    label: utils.string.t('ems.useExistingFiles'),
    value: attachedMailDocuments,
    maxLabelLengthForEllipsis: 10,
    options: docList || [],
    content: <MultiSelect id="attachments" search options={docList || []} />,
    handlers: { toggleOption, toggleSelectAll },
  };

  const removeAttachedDocument = (selectedDoc) => {
    setAttachedMailDocuments((oldArray) => oldArray.filter((item) => item?.id !== selectedDoc?.value));
  };

  const handleUploadedDocument = (data) => {
    const newFiles = data?.data?.documentDto;
    if (!utils.generic.isValidArray(newFiles)) return;
    const newDocs = newFiles?.map((doc) => ({ id: doc?.documentId, name: doc?.documentName }));
    setDocList((oldArray) => [...oldArray, ...newDocs]);
    setAttachedMailDocuments((oldArray) => [...oldArray, ...newDocs]);
  };

  const launchDmsUpload = () => (files) => {
    dispatch(addLoader('DmsUploadFiles'));
    dispatch(
      showModal({
        component: 'DMS_UPLOAD_FILES',
        props: {
          fullWidth: true,
          title: utils.string.t('dms.upload.modalItems.uploadDocuments'),
          hideCompOnBlur: false,
          maxWidth: 'lg',
          componentProps: {
            files,
            context: uploadOptions?.context,
            referenceId: uploadOptions?.referenceId,
            sourceId: uploadOptions?.sourceId,
            documentTypeKey: uploadOptions?.documentTypeKey,
            confirmLabel: utils.string.t('app.ok'),
            cancelLabel: utils.string.t('app.goBack'),
            confirmMessage: utils.string.t('processingInstructions.documentsWillNotBeSaved'),
            buttonColors: { confirm: 'secondary', cancel: 'primary' },
            postDmsDocumentsSuccess: (data) => handleUploadedDocument(data),
          },
        },
      })
    );
  };

  return (
    <EmailManagementServiceComposeMailView
      actions={actions}
      attachedMailDocuments={attachedMailDocuments}
      attachmentProps={attachmentProps}
      fields={fields}
      hasAttachedDocuments={hasAttachedDocuments}
      handlers={{ removeAttachedDocument, uploadFilesToDms: launchDmsUpload }}
    />
  );
}

export default EmailManagementServiceComposeMail;
