import React from 'react';

// app
import { FormActionsView } from './FormActions.view';

export function FormActions(props) {
  return <FormActionsView {...props} />;
}

export default FormActions;
