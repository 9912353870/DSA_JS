import React from 'react';
import { PDFCoverView } from './PDFCover.view';

export function PDFCover(props) {
  return <PDFCoverView {...props} />;
}

export default PDFCover;
