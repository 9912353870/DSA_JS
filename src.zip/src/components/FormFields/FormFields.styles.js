const styles = (theme) => ({
  fields: {},
  fieldsDialog: {
    flex: '1 1 auto',
    overflowY: 'auto',
    padding: theme.spacing(3, 4, 4),
  },
});

export default styles;
