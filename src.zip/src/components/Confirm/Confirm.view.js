import React from 'react';
import PropTypes from 'prop-types';

// app
import styles from './Confirm.styles';
import * as utils from 'utils';
import { Button, FormContainer, FormActions, Warning } from 'components';

// mui
import { makeStyles, Typography, Box } from '@material-ui/core';

ConfirmView.propTypes = {
  buttonColors: PropTypes.object,
  note: PropTypes.string,
  cancelLabel: PropTypes.string,
  confirmLabel: PropTypes.string,
  confirmMessage: PropTypes.node,
  confirmMessageText: PropTypes.node,
  warningMessage: PropTypes.string,
  hideCancelButton: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
  handleConfirm: PropTypes.func.isRequired,
};

export function ConfirmView({
  handleConfirm,
  handleClose,
  hideCancelButton,
  cancelLabel,
  confirmLabel,
  confirmMessage,
  buttonColors = { confirm: 'primary', cancel: 'default' },
  confirmMessageText,
  warningMessage,
  note,
}) {
  const classes = makeStyles(styles, { name: 'Confirm' })();

  return (
    <Box className={classes.root}>
      <Box className={classes.scrollableConfirmBody}>
        {confirmMessage && <Box p={2}>{confirmMessage}</Box>}

        {confirmMessageText && <Box p={2}>{confirmMessageText}</Box>}

        {note && (
          <Box py={0.5} px={2}>
            <Typography variant="body1">
              <strong>{note}</strong>
            </Typography>
          </Box>
        )}

        {warningMessage && (
          <Box p={1}>
            <Warning text={warningMessage} type="alert" align="center" size="large" icon />
          </Box>
        )}
      </Box>

      <FormContainer type="dialog">
        <FormActions type="dialog" divider={false}>
          {!hideCancelButton && (
            <Button text={cancelLabel || utils.string.t('app.cancel')} variant="text" color={buttonColors.cancel} onClick={handleClose} />
          )}
          <Button
            text={confirmLabel || utils.string.t('app.confirm')}
            onClick={handleConfirm}
            color={buttonColors.confirm}
            data-testid="app.confirm"
          />
        </FormActions>
      </FormContainer>
    </Box>
  );
}
