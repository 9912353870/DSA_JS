const styles = (theme) => ({
  title: {
    fontSize: theme.typography.pxToRem(13),
    fontWeight: theme.typography.fontWeightMedium,
  },
  icon: {
    flex: '0 1 auto',
    marginRight: 4,
    marginLeft: -2,
    fontSize: theme.typography.pxToRem(32),
    color: theme.palette.primary.main,

    '& > svg': {
      display: 'block',
    },
  },
  multiSelect: {
    flex: '0 1 auto',
    marginRight: 4,
    marginLeft: -2,
    fontSize: theme.typography.pxToRem(32),
    color: theme.palette.primary.main,
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'left',
    flexWrap: 'wrap',

    '& > *': {
      margin: theme.spacing(0.5),
    },
    marginTop: theme.spacing(1),
  },
  button: {
    border: `1px solid ${theme.palette.grey[500]}`,
    borderRadius: 4,
    backgroundColor: 'white',
  },
  noWrap: {
    whiteSpace: 'pre-line',
  },
  linkPopover: {
    display: 'inline-block !important',
  },
  uploadedDate: {
    color: theme.palette.secondary.main,
  },
  filterBar: {
    display: 'flex',
    flex: '0 !important',
    minWidth: 0,

    [theme.breakpoints.up('sm')]: {
      minWidth: '0 !important',
    },
  },
  grid: {
    padding: theme.spacing(0.25),
    fontWeight: theme.typography.fontWeightRegular,
  },
  label: {
    fontWeight: theme.typography.fontWeightMedium,
  },
  value: {
    marginLeft: 4,
  },
  fileIconColor: {
    color: `${theme.palette.primary.main} !important`,
  },
  fileNameSize: {
    fontSize: theme.typography.pxToRem(10),
  },

  tableHeaderCells: {
    background: 'white',
  },
  overFlowTable: {
    width: '100%',
    '&&': {
      [theme.breakpoints.up('md')]: {
        overflow: 'auto',
        height: 'calc(60vh - 100px)',
      },
      [theme.breakpoints.up('lg')]: {
        overflow: 'auto',
        height: 'calc(60vh - 100px)',
      },
      [theme.breakpoints.up('xl')]: {
        overflow: 'auto',
        height: 'calc(70vh - 100px)',
      },
    },
  },
  stickyColumnRight: {
    position: 'sticky',
    right: 0,
    background: '#fafafa',
    zIndex: '2',
  },
});

export default styles;
