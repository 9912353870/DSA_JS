export const styles = () => ({
  root: {
    fontSize: 11,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: '10mm',
  },
  confidential: {
    fontStyle: 'italic',
  },
});

export default styles;
