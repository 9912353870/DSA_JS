import React from 'react';
import { PDFFooterView } from './PDFFooter.view';

export function PDFFooter(props) {
  return <PDFFooterView {...props} />;
}

export default PDFFooter;
