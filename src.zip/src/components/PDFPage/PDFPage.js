import React from 'react';
import { PDFPageView } from './PDFPage.view';

export function PDFPage(props) {
  return <PDFPageView {...props} />;
}

export default PDFPage;
