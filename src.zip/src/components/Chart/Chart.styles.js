const styles = (theme) => ({
  root: {
    position: 'relative',
    margin: '0 auto',
  },
  scale: {
    maxWidth: '100%',
    maxHeight: '100%',
  },
});

export default styles;
