import React from 'react';

// app
import { AccordionView } from './Accordion.view';

export default function Accordion(props) {
  return <AccordionView {...props} />;
}
