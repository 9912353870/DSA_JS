const styles = () => ({
  root: {
    outline: 'none',
  },
});

export default styles;
