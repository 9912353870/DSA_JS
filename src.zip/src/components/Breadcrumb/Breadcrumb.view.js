import React from 'react';
import PropTypes from 'prop-types';
import { Link as RouterLink } from 'react-router-dom';
import classnames from 'classnames';
import * as utils from 'utils';

// app
import styles from './Breadcrumb.styles';
import { Link as BreadcrumbLink } from 'components';

// mui
import { makeStyles, Link, Typography, Box } from '@material-ui/core';

BreadcrumbView.propTypes = {
  links: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string,
      label: PropTypes.string,
      link: PropTypes.string,
      active: PropTypes.bool,
      state: PropTypes.object,
      onLinkClick: PropTypes.func,
    })
  ),
  path: PropTypes.string,
  testid: PropTypes.string,
};

export function BreadcrumbView({ links, path, testid }) {
  const classes = makeStyles(styles, { name: 'Breadcrumb' })();

  return (
    <ul className={classes.list} data-testid={`breadcrumb${testid ? `-${testid}` : ''}`}>
      {links?.map((item, index) => {
        return (
          <li className={classes.item} key={`${item?.name}-${index}`}>
            {item?.active && item?.link === path ? (
              <Typography
                variant="body2"
                className={classnames(classes.text, { [classes.active]: item?.active, [classes.largeFont]: item?.largeFont })}
                data-testid={`${item?.label}-Tab`}
              >
                {item.label}
              </Typography>
            ) : (
              <>
                {utils.generic.isFunction(item.onLinkClick) ? (
                  <Box px={1}>
                    <BreadcrumbLink
                      text={item.label}
                      handleClick={() => {
                        item.onLinkClick(item);
                      }}
                    />
                  </Box>
                ) : (
                  <Link
                    component={RouterLink}
                    to={{
                      pathname: item?.link,
                      ...(utils.generic.isValidObject(item?.state) && { state: item?.state }),
                    }}
                    variant="body2"
                    className={classnames(classes.text, classes.link, { [classes.active]: item.active })}
                  >
                    {item.label}
                  </Link>
                )}
              </>
            )}
            {index < links.length - 1 && <span className={classes.separator} />}
          </li>
        );
      })}
    </ul>
  );
}
