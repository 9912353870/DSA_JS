import React from 'react';

import { FilterDateRange } from 'components';
import { withKnobs, text, boolean } from '@storybook/addon-knobs';
import { Box } from '@material-ui/core';

export default {
  title: 'FilterDateRange',
  component: FilterDateRange,
  decorators: [withKnobs],
};

export const Default = () => {
  const filterState = {
    dateRange: {
      startDate: '',
      endDate: '',
    },
  };

  const handleValueChange = (date) => {
    alert(JSON.stringify(date));
  };

  return (
    <Box style={{ minWidth: 300 }}>
      <FilterDateRange
        title={text('Title', 'Date Range')}
        handleOnChange={handleValueChange}
        selectionKey="dateRange"
        selection={filterState.dateRange}
      />
    </Box>
  );
};
