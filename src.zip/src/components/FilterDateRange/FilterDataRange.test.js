// app
import { FilterDateRange } from './FilterDateRange';
import { render, screen } from 'tests';
import userEvent from '@testing-library/user-event';

describe('COMPONENTS › FilterDateRange', () => {
  const defaultProps = {
    title: 'Select Date Range',
    handleOnChange: jest.fn(),
  };
  global.scrollTo = jest.fn();

  const today = new Date();
  const yesterday = new Date(today);

  yesterday.setDate(yesterday.getDate() - 1);

  it('renders without crashing', () => {
    // arrange
    render(<FilterDateRange {...defaultProps} />);
    // assert
    expect(screen.getByTestId('button-filter-date-range')).toBeInTheDocument();
    expect(screen.getByText('Select Date Range')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('button-filter-date-range'));
    expect(screen.getByText('products.filter.selectDateRange')).toBeInTheDocument();

    expect(screen.getByTestId('close-date-filter-range')).toBeInTheDocument();
    expect(screen.getByText('products.filter.close')).toBeInTheDocument();
    expect(screen.getByText('products.filter.apply')).toBeInTheDocument();
    expect(screen.queryByTestId('filter-data-range-clear')).not.toBeInTheDocument();

    userEvent.click(screen.getByText('Yesterday'));
    userEvent.click(screen.getByText('products.filter.apply'));

    expect(defaultProps.handleOnChange).toHaveBeenCalledTimes(1);

    expect(screen.getByTestId('filter-data-range-clear')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('filter-data-range-clear'));
    expect(screen.queryByText('Select Date Range')).toBeInTheDocument();
    expect(screen.queryByTestId('filter-data-range-clear')).not.toBeInTheDocument();
  });

  it('close icon', async () => {
    // arrange
    render(<FilterDateRange {...defaultProps} />);
    // assert
    expect(screen.getByTestId('button-filter-date-range')).toBeInTheDocument();
    expect(screen.getByText('Select Date Range')).toBeInTheDocument();

    userEvent.click(screen.getByTestId('button-filter-date-range'));
    expect(screen.getByText('products.filter.selectDateRange')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('close-date-filter-range'));
  });
  it('close button', async () => {
    // arrange
    render(<FilterDateRange {...defaultProps} />);
    // assert
    expect(screen.getByTestId('button-filter-date-range')).toBeInTheDocument();
    expect(screen.getByText('Select Date Range')).toBeInTheDocument();

    userEvent.click(screen.getByTestId('button-filter-date-range'));
    expect(screen.getByText('products.filter.selectDateRange')).toBeInTheDocument();
    userEvent.click(screen.getByText('products.filter.close'));
  });
});
