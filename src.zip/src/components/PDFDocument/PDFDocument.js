import React from 'react';
import { PDFDocumentView } from './PDFDocument.view';

export function PDFDocument(props) {
  return <PDFDocumentView {...props} />;
}

export default PDFDocument;
