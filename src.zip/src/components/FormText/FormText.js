import React from 'react';

// app
import { FormTextView } from './FormText.view';

export default function FormText(props) {
  return <FormTextView {...props} />;
}
