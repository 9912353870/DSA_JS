const styles = (theme) => ({
  title: {
    fontSize: theme.typography.pxToRem(13),
    fontWeight: theme.typography.fontWeightMedium,
  },
  icon: {
    flex: '0 1 auto',
    marginRight: 4,
    marginLeft: -2,
    fontSize: theme.typography.pxToRem(32),
    color: theme.palette.primary.main,

    '& > svg': {
      display: 'block',
    },
  },
  inputPropsRoot: {
    fontSize: theme.typography.pxToRem(12),

    '& > input': {
      paddingTop: '5.5px !important',
      paddingBottom: '5.5px !important',
    },
  },
  tableToolbarRoot: {
    margin: theme.spacing(1, 0, 0, 0.75),
  },
  tableToolbarRootforClaims: {
    marginTop: theme.spacing(17.5),
  },
  fileDropWrapper: {
    padding: theme.spacing(1),
  },
  fileDropWrapperDisabled: {
    padding: theme.spacing(1),
    pointerEvents: 'none',
  },
  fileDropWrapperContainerDisabled: {
    cursor: 'not-allowed',
  },
  multiSelectContainer: {
    display: 'flex',
    justifyContent: 'left',
    alignItems: 'flex-start',
    flexWrap: 'wrap',
    marginTop: theme.spacing(2.5),
  },
  multiSelectTitle: {
    flex: '0 1 auto',
    marginTop: 3,
    marginRight: theme.spacing(1),
    color: theme.palette.primary.main,
  },
  fileIconColor: {
    color: `${theme.palette.primary.main} !important`,
  },
  fileNameSize: {
    fontSize: theme.typography.pxToRem(10),
  },
  link: {
    textDecoration: 'underline',
  },

  filterBarWrapper: ({ media }) => ({
    width: media?.mobile || media?.tablet ? '100%' : '60%',
    marginLeft: !media?.mobile && !media?.tablet && '40%',
  }),

  searchRow: {
    marginBottom: theme.spacing(1.5),
  },
  tableActionRoot: {
    margin: theme.spacing(1, 1),
  },
  paginationWrapper: {
    padding: theme.spacing(1),
  },

  tableHeaderCells: {
    background: 'white',
  },
  overFlowTable: {
    width: '100%',
    '&&': {
      [theme.breakpoints.up('md')]: {
        overflow: 'auto',
        height: 'calc(60vh - 100px)',
      },
      [theme.breakpoints.up('lg')]: {
        overflow: 'auto',
        height: 'calc(60vh - 100px)',
      },
      [theme.breakpoints.up('xl')]: {
        overflow: 'auto',
        height: 'calc(70vh - 100px)',
      },
    },
  },
  stickyColumnRight: {
    position: 'sticky',
    right: 0,
    background: '#fafafa',
    zIndex: '2',
  },
});

export default styles;
