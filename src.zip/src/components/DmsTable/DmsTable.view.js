import React from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';

// app
import styles from './DmsTable.styles';
import {
  TableHead,
  TableCell,
  PopoverMenu,
  TableActions,
  Warning,
  Avatar,
  FormFileDrop,
  Button,
  Tooltip,
  Skeleton,
  Pagination,
  Link,
  FilterBar,
} from 'components';
import { useSort, useMedia } from 'hooks';
import * as utils from 'utils';
import config from 'config';

// mui
import { Table, TableBody, Box, TableRow, Typography, makeStyles, TableContainer, Grid, Checkbox } from '@material-ui/core';
import DescriptionIcon from '@material-ui/icons/Description';
import CloudDownloadOutlined from '@material-ui/icons/CloudDownloadOutlined';
import CloudUploadOutlined from '@material-ui/icons/CloudUploadOutlined';
import CancelIcon from '@material-ui/icons/Cancel';
import LinkOffIcon from '@material-ui/icons/LinkOff';
import LinkIcon from '@material-ui/icons/Link';
import InsertDriveFileIcon from '@material-ui/icons/InsertDriveFile';

DmsTableView.propTypes = {
  user: PropTypes.object.isRequired,
  cols: PropTypes.array.isRequired,
  documents: PropTypes.array.isRequired,
  popoverActions: PropTypes.array.isRequired,
  selectedDocs: PropTypes.array.isRequired,
  showHeader: PropTypes.bool,
  canUpload: PropTypes.bool,
  canSearch: PropTypes.bool,
  canSendToGXB: PropTypes.bool,
  canUnlink: PropTypes.bool,
  canDelete: PropTypes.bool,
  canMultiSelect: PropTypes.bool,
  canLink: PropTypes.bool,
  isPremiumProcessing: PropTypes.bool,
  isWorkBasketOrAllCases: PropTypes.bool,
  fnolViewOptions: PropTypes.shape({
    isClaimsFNOL: PropTypes.bool,
    isClaimsUploadDisabled: PropTypes.bool,
    isDmsDocumentMenuDisabled: PropTypes.bool,
    claimsUploadWarningMsg: PropTypes.string,
    claimsSearchDocumentsTxt: PropTypes.string,
    uploadDocumentsTitle: PropTypes.string,
  }),
  isDmsFromPiRiskRef: PropTypes.bool.isRequired,
  isDmsFileViewGridDataLoading: PropTypes.bool,
  isSeniorManager: PropTypes.bool,
  isClaims: PropTypes.bool,
  getDocClassification: PropTypes.func,
  canLinkToParentContext: PropTypes.bool,
  parentContext: PropTypes.string,
  isAllSelectedDocsAreNotDeletable: PropTypes.bool.isRequired,
  isAllSelectedDocsAreGxbDocs: PropTypes.bool,
  filterBarSearchFields: PropTypes.array.isRequired,
  filterBarSearchActions: PropTypes.array.isRequired,
  handlers: PropTypes.shape({
    resetSearch: PropTypes.func.isRequired,
    submitSearch: PropTypes.func.isRequired,
    handleSort: PropTypes.func.isRequired,
    uploadModal: PropTypes.func.isRequired,
    handleCheckboxClick: PropTypes.func.isRequired,
    handleMultipleDownload: PropTypes.func.isRequired,
    handleMutipleUnlinking: PropTypes.func.isRequired,
    handleMutipleDelete: PropTypes.func.isRequired,
    handleMultipleSendToGXB: PropTypes.func.isRequired,
    handleMutipleLink: PropTypes.func.isRequired,
    linkDocToParentContext: PropTypes.func.isRequired,
  }).isRequired,
  pagination: PropTypes.shape({
    obj: PropTypes.object.isRequired,
    handlers: PropTypes.shape({
      handleChangePage: PropTypes.func.isRequired,
      handleChangeRowsPerPage: PropTypes.func.isRequired,
    }).isRequired,
  }).isRequired,
};

export function DmsTableView({
  user,
  cols: colsArr,
  sort: sortObj,
  documents,
  popoverActions,
  selectedDocs,
  showHeader,
  canUpload,
  canSearch,
  canSendToGXB,
  canUnlink,
  canDelete,
  canMultiSelect,
  canLink,
  fnolViewOptions,
  isDmsFromPiRiskRef,
  isDmsFileViewGridDataLoading,
  isSeniorManager,
  isClaims,
  getDocClassification,
  canLinkToParentContext,
  parentContext,
  isAllSelectedDocsAreNotDeletable,
  isAllSelectedDocsAreGxbDocs,
  filterBarSearchFields,
  filterBarSearchActions,
  handlers,
  pagination,
  isPremiumProcessing,
  isWorkBasketOrAllCases,
}) {
  const media = useMedia();
  const classes = makeStyles(styles, { name: 'DmsTable' })({ isMobile: media.mobile, media: media });

  const { isClaimsFNOL, isClaimsUploadDisabled, isDmsDocumentMenuDisabled, claimsUploadWarningMsg } = fnolViewOptions;

  const { cols, sort } = useSort(colsArr, sortObj, handlers.handleSort);

  const hasNoDocument = documents?.length === 0;
  const selectedDocLength = selectedDocs?.length;
  const hasNoDocumentSelected = selectedDocLength === 0;

  const TableActionsComponent = (
    <TableActions nestedClasses={{ root: classes.tableActionRoot }}>
      {showHeader && (
        <Box display="flex" alignItems="center">
          <Box className={classes.icon}>
            <DescriptionIcon />
          </Box>
          <Typography variant="body2" className={classes.title}>
            {utils.string.t('dms.view.documents.title')}
          </Typography>
        </Box>
      )}
    </TableActions>
  );

  return (
    <Box mt={2}>
      <Box>
        <Grid container>
          {canUpload && (
            <Grid item xs={4} className={isClaimsUploadDisabled ? classes.fileDropWrapperContainerDisabled : classes.fileDropWrapper}>
              <Tooltip title={(isClaimsUploadDisabled && claimsUploadWarningMsg) || ''} block placement="top">
                <Box className={(isClaimsUploadDisabled && classes.fileDropWrapperDisabled) || ''}>
                  <FormFileDrop
                    name="file"
                    attachedFiles=""
                    showUploadPreview={false}
                    componentProps={{
                      multiple: true,
                      disabled: isSeniorManager || isWorkBasketOrAllCases,
                    }}
                    dragLabel={utils.string.t('dms.upload.fileUploadTitle')}
                    onChange={handlers.uploadModal()}
                  />
                </Box>
              </Tooltip>
            </Grid>
          )}
          <Grid item xs={12}>
            <Grid container className={classes.searchRow}>
              <Grid item xs={6}>
                {TableActionsComponent}
              </Grid>
              <Grid item xs={6}>
                {canSearch && (
                  <Box className={classes.filterBarWrapper}>
                    <FilterBar fields={filterBarSearchFields} actions={filterBarSearchActions} />
                  </Box>
                )}
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Box>

      <TableContainer>
        <Box className={classes.overFlowTable}>
          <Table size="small" stickyHeader>
            <TableHead columns={cols} sorting={sort} nestedClasses={{ tableCell: classes.tableHeaderCells }} />
            <TableBody>
              {isDmsFileViewGridDataLoading ? (
                <TableRow>
                  <TableCell colSpan={cols.length}>
                    <Skeleton height={40} animation="wave" displayNumber={5} />
                  </TableCell>
                </TableRow>
              ) : (
                utils.generic.isValidArray(documents, true) &&
                documents?.map((doc) => {
                  const isGxbSrcDoc = Boolean(doc?.isUploadedOnGxb);
                  const isUploadedByLoginUser = doc?.createdByEmailId?.toLowerCase() === user?.emailId?.toLowerCase();
                  const refinedActions = isGxbSrcDoc
                    ? [...popoverActions].map((action) => {
                        const isDeleteAction = action.id === 'delete';
                        const isSendToGxbAction = action.id === 'sendToGXB';
                        const isEditMetaDataAction = action.id === 'editMetaData';
                        return isDeleteAction || isEditMetaDataAction || isSendToGxbAction ? { ...action, disabled: true } : action;
                      })
                    : Boolean(doc?.isLinkedToMultipleContexts)
                    ? [...popoverActions].map((action) => {
                        const isDeleteAction = action.id === 'delete';
                        return isDeleteAction ? { ...action, disabled: true } : action;
                      })
                    : !isUploadedByLoginUser
                    ? [...popoverActions].map((action) => {
                        const isDeleteAction = action.id === 'delete';
                        return isDeleteAction ? { ...action, disabled: true } : action;
                      })
                    : popoverActions;

                  const checked =
                    utils.generic.isValidArray(selectedDocs, true) &&
                    selectedDocs?.map((selDoc) => selDoc.documentId).includes(doc?.documentId);
                  return (
                    <TableRow key={doc?.documentId}>
                      <TableCell compact minimal>
                        {canMultiSelect && (
                          <Checkbox color="primary" checked={checked} onClick={(e) => handlers.handleCheckboxClick(e, doc)} />
                        )}
                      </TableCell>
                      {!isDmsFromPiRiskRef && <TableCell>{doc?.folderName}</TableCell>}
                      <TableCell>
                        <Link
                          target="_blank"
                          href={`${window.location.origin}/document/${doc?.documentId}/${doc?.fileName}`}
                          rel="noopener"
                          nestedClasses={{
                            link: classes.link,
                          }}
                          color="secondary"
                          tooltip={{ title: utils.string.t('dms.view.documentTooltip') }}
                          text={doc?.documentName}
                        />
                        {Boolean(Number(doc?.isUploadedOnGxb)) && (
                          <Box display={'flex'} alignItems={'center'}>
                            <Avatar size={20} border={false} avatarClasses={classes.fileIconColor} icon={InsertDriveFileIcon} />
                            <Typography className={classes.fileNameSize}>{utils.string.t('dms.view.gxb')}</Typography>
                          </Box>
                        )}
                      </TableCell>
                      <TableCell>{doc?.srcApplication?.toUpperCase()}</TableCell>
                      {!(isDmsFromPiRiskRef || isClaimsFNOL || isPremiumProcessing) && (
                        <TableCell>{doc?.hdriveFolder && doc?.hdriveFolder?.match(/.{1,19}/g).join('\n')}</TableCell>
                      )}
                      <TableCell>{doc?.documentTypeDescription}</TableCell>
                      <TableCell>{getDocClassification(doc?.docClassification)}</TableCell>
                      <TableCell>
                        {utils.string.t('format.date', { value: { date: doc?.updatedDate, format: config.ui.format.date.text } })}
                      </TableCell>
                      <TableCell>{doc?.createdByName}</TableCell>
                      <TableCell>{doc?.documentVersion}</TableCell>
                      {!(isClaimsFNOL || isClaims) && (
                        <TableCell>
                          {utils.string.t('format.date', { value: { date: doc?.createdDate, format: config.ui.format.date.text } })}
                        </TableCell>
                      )}
                      {!isDmsDocumentMenuDisabled && (
                        <TableCell className={classes.stickyColumnRight}>
                          <PopoverMenu id="view-menu-list" items={refinedActions} data={{ doc }} />
                        </TableCell>
                      )}
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </Box>

        {!isDmsFileViewGridDataLoading && hasNoDocument && (
          <Box mt={-17.5} p={1.5}>
            <Warning text={utils.string.t('dms.view.gridDataEmptyWarning')} type="info" align="center" size="large" icon />
          </Box>
        )}
      </TableContainer>

      <Grid container>
        <Grid item xs={6}>
          {canMultiSelect && !hasNoDocument && (
            <>
              <Box className={classes.multiSelectContainer}>
                <Box display="flex" flexDirection="column">
                  <Box display="flex">
                    <Box mr={1}>
                      <Button
                        icon={CloudDownloadOutlined}
                        iconWide
                        text={utils.string.t('dms.view.buttons.download')}
                        color="primary"
                        variant="outlined"
                        size="xsmall"
                        disabled={hasNoDocument || hasNoDocumentSelected}
                        onClick={() => handlers.handleMultipleDownload()}
                      />
                    </Box>
                    {canSendToGXB && (
                      <Box mr={1}>
                        <Button
                          icon={CloudUploadOutlined}
                          iconWide
                          text={utils.string.t('dms.view.buttons.sendToGXB')}
                          color="primary"
                          variant="outlined"
                          size="xsmall"
                          disabled={hasNoDocument || hasNoDocumentSelected || isAllSelectedDocsAreGxbDocs}
                          onClick={() => handlers.handleMultipleSendToGXB()}
                        />
                      </Box>
                    )}
                    {canUnlink && (
                      <Box mr={1}>
                        <Button
                          icon={LinkOffIcon}
                          iconWide
                          text={utils.string.t('dms.view.buttons.unlink')}
                          color="primary"
                          variant="outlined"
                          size="xsmall"
                          disabled={hasNoDocument || hasNoDocumentSelected || isWorkBasketOrAllCases}
                          onClick={() => handlers.handleMutipleUnlinking()}
                        />
                      </Box>
                    )}
                    {canDelete && (
                      <Box mr={1}>
                        <Button
                          icon={CancelIcon}
                          text={utils.string.t('dms.view.buttons.delete')}
                          color="primary"
                          variant="outlined"
                          size="xsmall"
                          disabled={hasNoDocument || hasNoDocumentSelected || isAllSelectedDocsAreNotDeletable || isWorkBasketOrAllCases}
                          onClick={() => handlers.handleMutipleDelete()}
                        />
                      </Box>
                    )}
                    {(canLink || canLinkToParentContext) && (
                      <Box mr={1}>
                        <Button
                          icon={LinkIcon}
                          text={`${utils.string.t('dms.view.buttons.linkTo')} ${canLinkToParentContext ? parentContext : ''}`}
                          color="primary"
                          variant="outlined"
                          size="xsmall"
                          disabled={hasNoDocument || hasNoDocumentSelected}
                          onClick={() =>
                            canLinkToParentContext ? handlers?.linkDocToParentContext(selectedDocs) : handlers.handleMutipleLink()
                          }
                        />
                      </Box>
                    )}
                  </Box>
                  <Box display="flex" alignItems="center" mt={0.5}>
                    <Typography variant="body2">
                      {utils.string.t('dms.view.selectedDoc', {
                        count: selectedDocLength,
                      })}
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </>
          )}
        </Grid>

        <Grid item xs={6}>
          <Box className={classes.paginationWrapper}>
            {utils.generic.isValidArray(documents, true) && (
              <Pagination
                page={get(pagination, 'obj.page')}
                count={get(pagination, 'obj.rowsTotal')}
                rowsPerPage={get(pagination, 'obj.rowsPerPage')}
                onChangePage={get(pagination, 'handlers.handleChangePage')}
                onChangeRowsPerPage={get(pagination, 'handlers.handleChangeRowsPerPage')}
              />
            )}
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
}
