import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { firstBy } from 'thenby';
import uniqBy from 'lodash/uniqBy';

// app
import { DmsTableView } from './DmsTable.view';
import * as utils from 'utils';
import {
  selectUser,
  showModal,
  hideModal,
  unlinkDmsViewDocuments,
  viewDocumentsDownload,
  viewDocumentsDelete,
  setDmsContext,
  viewDocumentsMultiDownload,
  selectContextSubType,
  getDmsEditMetadata,
  getDmsMetaData,
  postDmsDocumentsToGxb,
  addLoader,
  selectDmsFileViewGridDataLoader,
  selectUserRole,
  getViewTableDocuments,
  linkMultipleDmsDocuments,
  setDmsDirtyCheckFlag,
  enqueueNotification,
} from 'stores';
import * as constants from 'consts';
import { usePagination } from 'hooks';

// mui
import { Box, Typography } from '@material-ui/core';

DmsTable.propTypes = {
  columnsData: PropTypes.array.isRequired,
  showHeader: PropTypes.bool,
  canUpload: PropTypes.bool,
  canSearch: PropTypes.bool,
  canSendToGXB: PropTypes.bool,
  canUnlink: PropTypes.bool,
  canDelete: PropTypes.bool,
  canMultiSelect: PropTypes.bool,
  canEditMetaData: PropTypes.bool,
  canLink: PropTypes.bool,
  canLinkToParentContext: PropTypes.bool,
  fnolViewOptions: PropTypes.object,
  viewOptions: PropTypes.object,
  context: PropTypes.oneOf(['Claim', 'Loss', 'Policy', 'Task', 'Case', 'Processing Instruction']).isRequired,
  documentTypeKey: PropTypes.oneOf(Object.values(constants.DMS_DOCUMENT_TYPE_SECTION_KEYS)),
  referenceId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  isPremiumProcessing: PropTypes.bool,
  isWorkBasketOrAllCases: PropTypes.bool,
  sourceId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  parentLossRef: PropTypes.string,
  searchParamsAfterUpload: PropTypes.shape({
    referenceId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
    sectionType: PropTypes.string.isRequired,
  }),
  parentContext: PropTypes.string,
  parentContextId: PropTypes.string,
  refData: PropTypes.object,
  handlers: PropTypes.shape({
    onUnlinkorDeleteSuccess: PropTypes.func,
    onSelectFile: PropTypes.func,
    onClosingUploadModal: PropTypes.func,
    onLink: PropTypes.func,
    onSendToGxbSuccess: PropTypes.func,
  }),
};

DmsTable.defaultProps = {
  showHeader: true,
  canUpload: true,
  canSearch: true,
  canSendToGXB: false,
  canUnlink: true,
  canDelete: true,
  canMultiSelect: true,
  canEditMetaData: true,
  canLink: false,
  canLinkToParentContext: false,
  parentContext: '',
  parentContextId: '',
  fnolViewOptions: {
    isClaimsFNOL: false,
    isClaimsUploadDisabled: false,
    isDmsDocumentMenuDisabled: false,
    claimsSearchDocumentsTxt: utils.string.t('dms.view.searchDocuments'),
  },
  documentTypeKey: constants.DMS_DOCUMENT_TYPE_SECTION_KEYS.policy,
};

export default function DmsTable({
  columnsData,
  showHeader,
  canUpload,
  canSearch,
  canSendToGXB,
  canUnlink,
  canDelete,
  canMultiSelect,
  canEditMetaData,
  canLink,
  fnolViewOptions,
  viewOptions,
  uploadOptions,
  context,
  documentTypeKey,
  referenceId,
  sourceId,
  parentLossRef,
  searchParamsAfterUpload,
  handlers,
  canLinkToParentContext,
  parentContext,
  parentContextId,
  isPremiumProcessing,
  isWorkBasketOrAllCases,
}) {
  const dispatch = useDispatch();
  const user = useSelector(selectUser);

  const [search, setSearch] = useState('');
  const [originalTableData, setOriginalTableData] = useState([]);
  const [filteredTableData, setFilteredTableData] = useState([]);
  const [searchIndex, setSearchIndex] = useState([]);
  const [selectedDocs, setSelectedDocs] = useState([]);
  const [newPage, setNewPage] = useState(constants.DMS_PAGINATION_DEFAULT_PAGE);
  const [rowsPerPage, setRowsPerPage] = useState(constants.DMS_DEFAULT_ROWS_PER_PAGE);
  const DmsFileViewGridDataLoading = useSelector(selectDmsFileViewGridDataLoader);

  const contextSubType = useSelector(selectContextSubType);
  const currentUser = useSelector(selectUserRole);

  const xbInstanceId = sourceId ? sourceId : constants.DMS_CLAIM_SOURCE_ID;
  const [isDmsFileViewGridDataLoading, setIsDmsFileViewGridDataLoading] = useState(DmsFileViewGridDataLoading);

  const isAllSelectedDocsAreLinkedToMultipleContext = selectedDocs?.every((docs) => Boolean(docs?.isLinkedToMultipleContexts));
  const isAllSelectedDocsAreGxbDocs = selectedDocs?.every((doc) => Boolean(doc?.isUploadedOnGxb));
  const isAllSelectedDocsAreNotUploadedByLoginUser = selectedDocs?.every(
    (doc) => doc?.createdByEmailId?.toLowerCase() !== user?.emailId?.toLowerCase()
  );
  const isAllSelectedDocsAreNotDeletable =
    isAllSelectedDocsAreLinkedToMultipleContext || isAllSelectedDocsAreGxbDocs || isAllSelectedDocsAreNotUploadedByLoginUser;

  useEffect(() => {
    setIsDmsFileViewGridDataLoading(DmsFileViewGridDataLoading);
  }, [DmsFileViewGridDataLoading]);

  const isSeniorManager =
    utils.generic.isValidArray(currentUser, true) &&
    currentUser.some((item) => [constants.SENIOR_MANAGER.toLowerCase()].includes(item.name.toLowerCase()));

  useEffect(() => {
    const tableDataString = (data, allValues) => {
      if (!allValues) allValues = [];
      for (const key in data) {
        if (typeof data[key] === 'object') tableDataString(data[key], allValues);
        else allValues.push(`${data[key]}' '`);
      }
      return allValues;
    };

    const setInitialTableData = () => {
      setOriginalTableData(columnsData);
      setFilteredTableData(columnsData);
      const searchInd = columnsData?.map((data) => {
        const allValues = tableDataString(data);
        return { allValues: allValues.toString() };
      });
      setSearchIndex(searchInd);
    };

    setInitialTableData();
  }, [columnsData]);

  useEffect(() => {
    if (search) {
      const newFilteredTableData = searchIndex?.map((data, index) => {
        if (data?.allValues?.toLowerCase().indexOf(search.toLowerCase()) >= 0) return originalTableData[index];
        return null;
      });
      setFilteredTableData(
        newFilteredTableData?.filter((data) => {
          if (data) return true;
          return false;
        })
      );
    } else setFilteredTableData(originalTableData);
  }, [search, originalTableData, searchIndex]);

  const isDmsFromPiRiskRef = [
    constants.DMS_DOCUMENT_TYPE_SECTION_KEYS.piEndorsement,
    constants.DMS_DOCUMENT_TYPE_SECTION_KEYS.piFABorder,
    constants.DMS_DOCUMENT_TYPE_SECTION_KEYS.piClosingFdo,
  ].includes(documentTypeKey);

  useEffect(() => {
    setFilteredTableData(originalTableData?.slice(newPage * rowsPerPage, newPage * rowsPerPage + rowsPerPage));
  }, [newPage, rowsPerPage, originalTableData]);

  const isClaims = utils.dms.checkIfClaimsScreenContext(context) || false;

  const cols = [
    {
      id: 'multiSelect',
      visible: true,
    },
    ...(!isDmsFromPiRiskRef
      ? [
          {
            id: 'folderName',
            label: utils.string.t('dms.view.columns.folderName'),
            sort: { type: 'lexical', direction: 'asc' },
          },
        ]
      : []),
    { id: 'documentName', label: utils.string.t('dms.view.columns.documentName'), sort: { type: 'lexical', direction: 'asc' } },
    { id: 'documentSource', label: utils.string.t('dms.view.columns.documentSource'), sort: { type: 'lexical', direction: 'asc' } },
    ...(!(isDmsFromPiRiskRef || fnolViewOptions?.isClaimsFNOL || isPremiumProcessing)
      ? [
          {
            id: 'hDriveFolders',
            label: utils.string.t('dms.view.columns.hDriveFolders'),
            sort: { type: 'lexical', direction: 'asc' },
          },
        ]
      : []),
    { id: 'documentTypeDescription', label: utils.string.t('dms.view.columns.documentType'), sort: { type: 'lexical', direction: 'asc' } },
    {
      id: 'docClassification',
      label: utils.string.t('dms.view.columns.documentClassification'),
      sort: { type: 'lexical', direction: 'asc' },
    },
    { id: 'updatedDate', label: utils.string.t('dms.view.columns.uploadedDate'), sort: { type: 'date', direction: 'asc' } },
    { id: 'createdByName', label: utils.string.t('dms.view.columns.uploadedBy'), sort: { type: 'lexical', direction: 'asc' } },
    {
      id: 'documentVersion',
      label: utils.string.t('dms.view.columns.documentVersion'),
      sort: { type: 'lexical', direction: 'asc' },
    },
    ...(!(fnolViewOptions?.isClaimsFNOL || isClaims)
      ? [
          {
            id: 'createdDate',
            label: utils.string.t('dms.view.columns.creationDate'),
            sort: { type: 'date', direction: 'asc' },
            visible: true,
          },
        ]
      : []),
    { id: 'actions', menu: true, visible: true, stickyRight: true },
  ];

  const resetToDefaultValues = () => {
    handlers.onUnlinkorDeleteSuccess();
    setSelectedDocs([]);
  };

  const handleChangePage = (newPage) => {
    setNewPage(newPage);
  };

  const handleChangeRowsPerPage = (rowsPerPage) => {
    setNewPage(constants.DMS_PAGINATION_DEFAULT_PAGE);
    setRowsPerPage(rowsPerPage);
  };

  const pagination = usePagination(
    filteredTableData || [],
    {
      page: newPage || constants.DMS_PAGINATION_DEFAULT_PAGE,
      rowsTotal: originalTableData.length || 0,
      rowsPerPage: rowsPerPage,
    },
    handleChangePage,
    handleChangeRowsPerPage
  );

  const getSuccessAndFailedDocs = (docs, data = []) => {
    const successAndFailureDocs = data;
    const successDocsIds = Object.entries(successAndFailureDocs)
      .filter(([key, value]) => value?.toString()?.toLowerCase() === 'success' || value?.toString()?.toLowerCase() === 'true')
      .reduce((acc, [key, value]) => {
        return [...acc, key];
      }, []);
    const failedDocsIds = Object.entries(successAndFailureDocs)
      .filter(([key, value]) => value?.toString()?.toLowerCase() === 'failed' || value?.toString()?.toLowerCase() === 'false')
      .reduce((acc, [key, value]) => {
        return [...acc, key];
      }, []);

    const failedDocs = docs?.filter((doc) => failedDocsIds?.includes(doc?.documentId.toString())) || [];
    const successDocs = docs?.filter((doc) => successDocsIds?.includes(doc?.documentId.toString())) || [];
    return { failedDocs, successDocs };
  };

  const documentsStatusModal = ({
    successDocs,
    botDocs = [],
    failedDocs,
    title,
    successDocsTitle,
    botDocsTitle = '',
    failedDocsTitle,
    confirmLabel,
  }) => {
    dispatch(
      showModal({
        component: 'DMS_SUCCESS_FAILED_DOCUMENTS_STATUS',
        props: {
          fullWidth: true,
          title,
          maxWidth: 'xs',
          hideCancelButton: true,
          componentProps: {
            selectedDocs,
            successDocs,
            botDocs,
            failedDocs,
            successDocsTitle,
            botDocsTitle,
            failedDocsTitle,
            confirmLabel,
            submitHandler: () => {
              dispatch(hideModal('DMS_SUCCESS_FAILED_DOCUMENTS_STATUS'));
            },
            clickXHandler: () => {
              dispatch(hideModal('DMS_SUCCESS_FAILED_DOCUMENTS_STATUS'));
            },
            clickOutSideHandler: () => {
              dispatch(hideModal('DMS_SUCCESS_FAILED_DOCUMENTS_STATUS'));
            },
          },
        },
      })
    );
  };

  const confirmDocumentUnlink = (unlinkDocsList) => {
    const unlinkDocsListParams = unlinkDocsList?.map((d) => {
      return {
        documentId: d?.documentId,
        referenceId: d?.referenceId,
        sectionType: d?.sectionType,
        ...(d?.xbInstanceId ? { sourceID: d?.xbInstanceId } : {}),
      };
    });
    const requestParamsLength = unlinkDocsListParams?.length;

    dispatch(
      showModal({
        component: 'CONFIRM',
        props: {
          fullWidth: true,
          title: utils.string.t('dms.view.unlinkDocument.title'),
          maxWidth: 'xs',
          componentProps: {
            confirmLabel: utils.string.t('dms.view.unlinkDocument.confirmLabel'),
            confirmMessage:
              requestParamsLength === 1
                ? utils.string.t('dms.view.unlinkDocument.confirmMessage')
                : utils.string.t('dms.view.unlinkDocument.confirmMessageForMulti', {
                    count: requestParamsLength,
                  }),
            submitHandler: () =>
              dispatch(unlinkDmsViewDocuments(unlinkDocsListParams)).then((response) => {
                if (response?.status === constants.API_RESPONSE_OK) {
                  const { failedDocs, successDocs } = getSuccessAndFailedDocs(unlinkDocsList, response?.data);
                  const documentsStatusModalParams = {
                    successDocs,
                    failedDocs,
                    title: utils.string.t('dms.view.unlinkDocument.unlinkDocumentsTitle'),
                    successDocsTitle: utils.string.t('dms.view.unlinkDocument.unlinkSuccessDocsTitle', {
                      successDocsLength: successDocs.length,
                    }),
                    failedDocsTitle: utils.string.t('dms.view.unlinkDocument.unlinkFailedDocsTitle', {
                      failedDocsLength: failedDocs.length,
                    }),
                    confirmLabel: utils.string.t('app.ok'),
                  };
                  documentsStatusModal(documentsStatusModalParams);
                  resetToDefaultValues();
                }
              }),
          },
        },
      })
    );
  };

  const getConfirmMessage = ({ dontDocs, doDocs, dontDocsMessage, doDocsRemainingConfirmMessage, doDocsConfirmMessage }) => {
    return utils.generic.isValidArray(dontDocs, true) ? (
      <Box>
        <Typography>{dontDocsMessage}:</Typography>
        <ul>
          {dontDocs?.map((doc) => (
            <li key={doc.documentId}>{doc?.documentName}</li>
          ))}
        </ul>
        {utils.generic.isValidArray(doDocs, true) && <Typography>{doDocsRemainingConfirmMessage}</Typography>}
      </Box>
    ) : (
      <Box>
        <Typography>{doDocsConfirmMessage}</Typography>
      </Box>
    );
  };

  const confirmDocumentDelete = (docs) => {
    const linkedDocList = docs?.filter((docs) => Boolean(docs?.isLinkedToMultipleContexts));
    const gxbDocsList = docs?.filter((doc) => Boolean(doc?.isUploadedOnGxb));
    const docsNotUploadedByLoginUser = docs?.filter((doc) => doc?.createdByEmailId?.toLowerCase() !== user?.emailId?.toLowerCase());
    const gxbLinkedLoginUserDocs = uniqBy([...linkedDocList, ...gxbDocsList, ...docsNotUploadedByLoginUser], 'documentId');

    const remainingDocs = docs?.filter(
      (doc) => gxbLinkedLoginUserDocs?.map((gluDoc) => gluDoc?.documentId)?.indexOf(doc?.documentId) === -1
    );
    const documentIds = remainingDocs?.map((doc) => doc?.documentId);

    dispatch(
      showModal({
        component: 'CONFIRM',
        props: {
          fullWidth: true,
          title: utils.string.t('dms.view.deleteDocument.title'),
          maxWidth: 'xs',
          componentProps: {
            confirmLabel: utils.generic.isValidArray(remainingDocs, true)
              ? utils.string.t('dms.view.deleteDocument.confirmLabel')
              : utils.string.t('app.ok'),
            hideCancelButton: !utils.generic.isValidArray(remainingDocs, true),
            confirmMessage: getConfirmMessage({
              dontDocs: gxbLinkedLoginUserDocs,
              doDocs: remainingDocs,
              dontDocsMessage: utils.string.t('dms.view.deleteDocument.dontDocsMessage'),
              doDocsRemainingConfirmMessage: utils.string.t('dms.view.deleteDocument.doDocsRemainingConfirmMessage'),
              doDocsConfirmMessage: utils.string.t('dms.view.deleteDocument.doDocsConfirmMessage'),
            }),
            submitHandler: () => {
              if (utils.generic.isValidArray(remainingDocs, true)) {
                dispatch(viewDocumentsDelete(documentIds)).then((response) => {
                  if (response?.status === constants.API_RESPONSE_OK) {
                    const { failedDocs, successDocs } = getSuccessAndFailedDocs(remainingDocs, response?.data);
                    const documentsStatusModalParams = {
                      successDocs,
                      failedDocs,
                      title: utils.string.t('dms.view.deleteDocument.deleteDocumentTitle'),
                      successDocsTitle: utils.string.t('dms.view.deleteDocument.deleteSuccessDocsTitle', {
                        successDocsLength: successDocs.length,
                      }),
                      failedDocsTitle: utils.string.t('dms.view.deleteDocument.deleteFailedDocsTitle', {
                        failedDocsLength: failedDocs.length,
                      }),
                      confirmLabel: utils.string.t('app.ok'),
                    };
                    documentsStatusModal(documentsStatusModalParams);
                    resetToDefaultValues();
                  }
                });
              } else {
                dispatch(hideModal('CONFIRM'));
              }
            },
          },
        },
      })
    );
  };

  const showVersionHistoryModal = (docData) => {
    dispatch(
      showModal({
        component: 'DMS_VERSION_HISTORY',
        props: {
          fullWidth: true,
          title: utils.string.t('dms.view.versionHistory.title'),
          maxWidth: 'xs',
          componentProps: {
            docData: docData,
          },
        },
      })
    );
  };

  const launchEditMetadataModel = async (doc) => {
    const refinedReferenceId = getRefIdForContext();
    const metaDataSectionRef = referenceId;
    const metaDataReferenceId = uploadOptions?.metaDataReferenceId;

    dispatch(setDmsContext(context));
    await dispatch(getDmsMetaData(context, xbInstanceId, metaDataSectionRef, metaDataReferenceId));
    await dispatch(getDmsEditMetadata(doc?.documentId, doc?.docClassification)).then((res) => {
      if (res?.status === constants.API_RESPONSE_OK) {
        dispatch(
          showModal({
            component: 'DMS_EDIT_META_DATA',
            props: {
              fullWidth: true,
              title: utils.string.t('dms.view.editMetadata.title'),
              maxWidth: 'xl',
              componentProps: {
                docData: doc,
                context,
                referenceId: refinedReferenceId,
                selectedSourceId: sourceId,
                documentTypeKey: documentTypeKey,
                searchParamsAfterUpload,
                viewOptions,
                cancelHandler: () => {
                  dispatch(hideModal('DMS_EDIT_META_DATA'));
                },
              },
            },
          })
        );
      }
    });
  };

  const linkDocToParentContext = (docs) => {
    const requestParams = docs?.map((doc) => {
      return {
        documentId: doc?.documentId,
        referenceId: parentContextId,
        sectionType: parentContext,
        ...(sourceId ? { sourceID: sourceId } : {}),
      };
    });

    if (!utils.generic.isInvalidOrEmptyArray(requestParams)) {
      dispatch(linkMultipleDmsDocuments(requestParams)).then((response) => {
        if (response?.status === constants.API_RESPONSE_OK) {
          resetToDefaultValues();
        }
      });
    }
  };

  const popoverActions = [
    {
      id: 'download',
      label: utils.string.t('dms.view.popOverMenuItems.download'),
      callback: ({ doc }) => dispatch(viewDocumentsDownload(doc)),
    },
    ...(canSendToGXB
      ? [
          {
            id: 'sendToGXB',
            label: utils.string.t('dms.view.popOverMenuItems.sendToGXB'),
            callback: ({ doc }) => confirmDocumentSendToGXB([doc]),
          },
        ]
      : []),
    ...(canUnlink
      ? [
          {
            id: 'unlink',
            label: utils.string.t('dms.view.popOverMenuItems.unlink'),
            callback: ({ doc }) => confirmDocumentUnlink([doc]),
          },
        ]
      : []),
    ...(canDelete
      ? [
          {
            id: 'delete',
            label: utils.string.t('dms.view.popOverMenuItems.delete'),
            callback: ({ doc }) => confirmDocumentDelete([doc]),
          },
        ]
      : []),
    {
      id: 'versionHistory',
      label: utils.string.t('dms.view.popOverMenuItems.versionHistory'),
      callback: ({ doc }) => showVersionHistoryModal(doc),
    },
    ...(canEditMetaData
      ? [
          {
            id: 'editMetaData',
            label: utils.string.t('dms.view.popOverMenuItems.editMetadata'),
            callback: ({ doc }) => launchEditMetadataModel(doc),
          },
        ]
      : []),
    ...(canLink
      ? [
          {
            id: 'LinkTo',
            label: utils.string.t('dms.view.popOverMenuItems.linkTo'),
            callback: ({ doc }) => handlers.onLink([doc], resetToDefaultValues),
          },
        ]
      : []),
    ...(canLinkToParentContext
      ? [
          {
            id: 'LinkToParentContext',
            label: `${utils.string.t('dms.view.popOverMenuItems.linkTo')} ${parentContext}`,
            callback: ({ doc }) => linkDocToParentContext([doc]),
          },
        ]
      : []),
  ];

  const resetSearch = () => {
    setSearch('');
  };

  const submitSearch = (query) => {
    setSearch(query);
  };

  const handleSort = (by, dir) => {
    const sortedTableData = filteredTableData?.sort(firstBy(utils.sort.array('lexical', by, dir)));
    setFilteredTableData(sortedTableData);
  };

  const closeXHandler = (files) => {
    if (files?.length === 0) {
      dispatch(hideModal('DMS_UPLOAD_FILES'));
    } else {
      dispatch(setDmsDirtyCheckFlag(true));
    }
  };

  const launchDmsUpload = () => (files) => {
    dispatch(addLoader('DmsUploadFiles'));
    const refinedReferenceId = getRefIdForContext();

    dispatch(
      showModal({
        component: 'DMS_UPLOAD_FILES',
        props: {
          fullWidth: true,
          title: utils.string.t('dms.upload.modalItems.uploadDocuments'),
          hideCompOnBlur: false,
          maxWidth: 'lg',
          componentProps: {
            uploadOptions,
            files,
            context,
            referenceId: refinedReferenceId,
            sourceId,
            documentTypeKey,
            searchParamsAfterUpload,
            confirmLabel: utils.string.t('app.ok'),
            cancelLabel: utils.string.t('app.goBack'),
            confirmMessage: utils.string.t('processingInstructions.documentsWillNotBeSaved'),
            buttonColors: { confirm: 'secondary', cancel: 'primary' },
            onClosingUploadModal: () => handleUploadModalClose(),
            cancelHandler: () => {},
            clickXHandler: () => {
              closeXHandler(files);
            },
          },
        },
      })
    );
  };

  const handleUploadModalClose = () => {
    if (!utils.dmsFormatter.isDmsFromPiInstruction(documentTypeKey)) {
      // Refresh DmsTable Data once Upload is done
      dispatch(
        getViewTableDocuments({
          ...(searchParamsAfterUpload
            ? searchParamsAfterUpload
            : {
                referenceId: getRefIdForContext(),
                sectionType: context,
                documentTypeKey,
                parentLossRef,
                ...(sourceId ? { sourceID: sourceId } : {}),
                multiRequestLinkedViewPayload: viewOptions?.multiRequestLinkedViewPayload,
              }),
        })
      );
    }
    if (utils.generic.isFunction(handlers.onClosingUploadModal)) handlers.onClosingUploadModal();
  };

  const handleCheckboxClick = (e, doc) => {
    e.stopPropagation();
    let newlySelectedDocs = [...selectedDocs, doc];
    if (selectedDocs?.find((docs) => docs.documentId === doc.documentId)) {
      newlySelectedDocs = newlySelectedDocs.filter((selectedDoc) => selectedDoc.documentId !== doc.documentId);
    }

    if (utils.generic.isFunction(handlers?.onSelectFile)) {
      handlers.onSelectFile(newlySelectedDocs);
    }

    setSelectedDocs(newlySelectedDocs);
  };

  const handleMultipleDownload = () => {
    const selectedDocIds = selectedDocs?.map((docId) => docId.documentId);
    if (selectedDocs?.length !== 1) {
      dispatch(viewDocumentsMultiDownload(selectedDocIds));
      return;
    }
    dispatch(viewDocumentsDownload(selectedDocs?.[0]));
  };

  const confirmDocumentSendToGXB = (docs) => {
    const gxbDocs = docs?.filter((doc) => Boolean(doc?.isUploadedOnGxb)) || [];
    const nonGxbDocs = docs?.filter((doc) => !Boolean(doc?.isUploadedOnGxb)) || [];
    const requestParams = nonGxbDocs?.map((d) => {
      return {
        documentId: d?.documentId,
        referenceId: d?.referenceId,
        sectionType: d?.sectionType,
      };
    });

    dispatch(
      showModal({
        component: 'CONFIRM',
        props: {
          fullWidth: true,
          title: utils.string.t('dms.view.sendToGxb.title'),
          maxWidth: 'xs',
          componentProps: {
            confirmLabel: utils.generic.isValidArray(requestParams, true)
              ? utils.string.t('dms.view.sendToGxb.confirmLabel')
              : utils.string.t('app.ok'),
            hideCancelButton: !utils.generic.isValidArray(requestParams, true),
            confirmMessage: getConfirmMessage({
              dontDocs: gxbDocs,
              doDocs: nonGxbDocs,
              dontDocsMessage: utils.string.t('dms.view.sendToGxb.dontDocsMessage'),
              doDocsRemainingConfirmMessage: utils.string.t('dms.view.sendToGxb.doDocsRemainingConfirmMessage'),
              doDocsConfirmMessage: utils.string.t('dms.view.sendToGxb.doDocsConfirmMessage'),
            }),
            submitHandler: () => {
              dispatch(postDmsDocumentsToGxb(requestParams)).then((response) => {
                if (response?.status === constants.API_RESPONSE_OK) {
                  const successAndFailureDocs = response?.data;
                  const successfullyUploadedToGxbDocs = successAndFailureDocs
                    ?.filter((doc) => Boolean(doc?.isDocumentUploaded) && !Boolean(doc?.isBotCall))
                    ?.map((a) => ({ documentId: a?.documentId, documentName: a?.fileName }));
                  const uploadTakingCareByBOTDocs = successAndFailureDocs
                    ?.filter((doc) => !Boolean(doc?.isDocumentUploaded) && Boolean(doc?.isBotCall))
                    ?.map((a) => ({ documentId: a?.documentId, documentName: a?.fileName }));
                  const uploadFailedDocs = successAndFailureDocs
                    ?.filter((doc) => !Boolean(doc?.isDocumentUploaded) && !Boolean(doc?.isBotCall))
                    ?.map((a) => ({ documentId: a?.documentId, documentName: a?.fileName }));

                  const documentsStatusModalParams = {
                    successDocs: successfullyUploadedToGxbDocs,
                    botDocs: uploadTakingCareByBOTDocs,
                    failedDocs: uploadFailedDocs,
                    title: utils.string.t('dms.view.sendToGxb.gxbDocumentTitle'),
                    successDocsTitle: utils.string.t('dms.view.sendToGxb.sendToGxbSuccessDocsTitle', {
                      successDocsLength: successfullyUploadedToGxbDocs?.length,
                    }),
                    botDocsTitle: utils.string.t('dms.view.sendToGxb.sendToGxbBotDocsTitle', {
                      botDocsLength: uploadTakingCareByBOTDocs?.length,
                    }),
                    failedDocsTitle: utils.string.t('dms.view.sendToGxb.sendToGxbFailedDocsTitle', {
                      failedDocsLength: uploadFailedDocs?.length,
                    }),
                    confirmLabel: utils.string.t('app.ok'),
                  };
                  documentsStatusModal(documentsStatusModalParams);
                  resetToDefaultValues();
                } else {
                  dispatch(hideModal('CONFIRM'));
                }
              });
            },
          },
        },
      })
    );
  };

  const handleMultipleSendToGXB = () => {
    confirmDocumentSendToGXB(selectedDocs);
  };

  const handleMutipleUnlinking = () => {
    confirmDocumentUnlink(selectedDocs);
  };

  const handleMutipleDelete = () => {
    confirmDocumentDelete(selectedDocs);
  };

  const handleMutipleLink = () => {
    handlers.onLink(selectedDocs, resetToDefaultValues);
  };

  const getRefIdForContext = () => {
    const { type, caseIncidentNotesID, refId } = contextSubType;
    if (type === constants.DMS_TASK_SUB_CONTEXT_TYPES.rfiResponse) {
      return caseIncidentNotesID ? refId + '-' + caseIncidentNotesID : refId;
    } else if (
      type === constants.DMS_TASK_SUB_CONTEXT_TYPES.rfi ||
      type === constants.DMS_TASK_SUB_CONTEXT_TYPES.adhoc ||
      type === constants.DMS_TASK_SUB_CONTEXT_TYPES.manualSanctionCheck
    ) {
      return refId;
    } else {
      return referenceId;
    }
  };

  const docClassification = utils?.dmsFormatter?.getDocumentClassificationList();

  const docClassificationList = new Map(
    docClassification?.map((item) => {
      return [item?.id, item?.value];
    })
  );

  const getDocClassification = (value) => {
    return docClassificationList?.get(Number(value));
  };

  const filterBarSearchFields = [
    {
      name: 'query',
      minChar: '4',
      type: 'text',
      placeholder: utils.string.t('dms.view.searchDocuments'),
      defaultValue: '',
      gridSize: { xs: 12 },
      muiComponentProps: {
        autoComplete: 'off',
      },
    },
  ];
  const filterBarSearchActions = [
    {
      name: 'filter',
      label: utils.string.t('app.filter'),
      handler: (values) => {
        if (values?.query) {
          submitSearch(values?.query);
        } else {
          dispatch(enqueueNotification(utils.string.t('claims.loss.searchLossAlert', 'error')));
        }
      },
    },
    {
      name: 'reset',
      label: utils.string.t('app.reset'),
      handler: (e) => {
        resetSearch();
      },
    },
  ];

  // abort
  if (!columnsData) return null;

  return (
    <DmsTableView
      isPremiumProcessing={isPremiumProcessing}
      isWorkBasketOrAllCases={isWorkBasketOrAllCases}
      user={user}
      cols={cols}
      documents={filteredTableData}
      pagination={pagination}
      popoverActions={popoverActions}
      showHeader={showHeader}
      canUpload={canUpload}
      canSearch={canSearch}
      canSendToGXB={canSendToGXB}
      canUnlink={canUnlink}
      canDelete={canDelete}
      canMultiSelect={canMultiSelect}
      canLink={canLink}
      fnolViewOptions={fnolViewOptions}
      selectedDocs={selectedDocs}
      isDmsFromPiRiskRef={isDmsFromPiRiskRef}
      isDmsFileViewGridDataLoading={isDmsFileViewGridDataLoading}
      isSeniorManager={isSeniorManager}
      isClaims={isClaims}
      getDocClassification={getDocClassification}
      canLinkToParentContext={canLinkToParentContext}
      parentContext={parentContext}
      isAllSelectedDocsAreNotDeletable={isAllSelectedDocsAreNotDeletable}
      isAllSelectedDocsAreGxbDocs={isAllSelectedDocsAreGxbDocs}
      filterBarSearchFields={filterBarSearchFields}
      filterBarSearchActions={filterBarSearchActions}
      handlers={{
        resetSearch: resetSearch,
        submitSearch: submitSearch,
        handleSort: handleSort,
        uploadModal: launchDmsUpload,
        handleCheckboxClick: handleCheckboxClick,
        handleMultipleDownload: handleMultipleDownload,
        handleMutipleUnlinking: handleMutipleUnlinking,
        handleMutipleDelete: handleMutipleDelete,
        handleMultipleSendToGXB: handleMultipleSendToGXB,
        handleMutipleLink: handleMutipleLink,
        linkDocToParentContext,
      }}
    />
  );
}
