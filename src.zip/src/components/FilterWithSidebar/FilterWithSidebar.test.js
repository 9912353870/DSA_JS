import FilterWithSidebar from './FilterWithSidebar';
import { render, screen, waitForElementToBeRemoved, waitFor } from 'tests';
import userEvent from '@testing-library/user-event';
import fetchMock from 'fetch-mock';

describe('COMPONENTS › FilterWithSidebar', () => {
  const onSubmitFilter = jest.fn();

  beforeEach(() => {
    fetchMock.get('glob:*/api/*', { body: { status: 'success', data: { id: 1 } } });
  });

  afterEach(() => {
    fetchMock.restore();
  });

  it('renders without crashing', async () => {
    // arrange
    render(<FilterWithSidebar size="small" onSubmitFilter={onSubmitFilter} />);

    // assert
    expect(screen.getByTestId('button-filter-with-sidebar')).toBeInTheDocument();
    userEvent.click(screen.getByTestId('button-filter-with-sidebar'));
    await waitFor(() => expect(screen.getByTestId('drawer-filter-with-sidebar')).toBeInTheDocument());

    expect(screen.getByText('products.filter.title')).toBeInTheDocument();
    expect(screen.getByText('products.filter.clearAll')).toBeInTheDocument();

    userEvent.click(screen.getByText('products.filter.clearAll'));
    expect(screen.queryByTestId('drawer-filter-with-sidebar')).toBeInTheDocument();

    userEvent.click(screen.getByTestId('button-filter-with-sidebar'));
    expect(screen.getByTestId('drawer-filter-with-sidebar')).toBeInTheDocument();

    userEvent.click(screen.getByTestId('close-button-filter-sidebar'));
    await waitForElementToBeRemoved(() => screen.getByTestId('drawer-filter-with-sidebar'));
    expect(screen.queryByTestId('drawer-filter-with-sidebar')).not.toBeInTheDocument();
  });

  it('Filter button is disabled if disabled=true', async () => {
    // arrange
    render(<FilterWithSidebar size="small" onSubmitFilter={onSubmitFilter} disabled={true} />);
    expect(screen.getByTestId('button-filter-with-sidebar')).toBeDisabled();
  });
});
