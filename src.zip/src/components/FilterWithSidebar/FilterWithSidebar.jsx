import { useEffect } from 'react';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
import isEmpty from 'lodash/isEmpty';
import isEqual from 'lodash/isEqual';

// app
import {
  getClients,
  selectProductsSorted,
  selectPartyClientsSorted,
  selectPartyClientLoading,
  setRiskFilters,
  selectRiskFilters,
  setRiskFilterStatus,
} from 'stores';
import CloseIcon from '@material-ui/icons/Close';
import FilterListIcon from '@material-ui/icons/FilterList';
import { Box, Button, Drawer, Divider, IconButton, Typography, makeStyles } from '@material-ui/core';

import { Badge, CustomAutocompleteMui, FilterDateRange } from 'components';

import * as utils from 'utils';
import { styles } from './FilterWithSidebar.styles';

FilterWithSidebar.propTypes = {
  onSubmitFilter: PropTypes.func,
};

const initialState = {
  products: [],
  clients: [],
  inceptionDateRange: {},
  expiryDateRange: {},
};

export default function FilterWithSidebar({ size, onSubmitFilter, disabled = false }) {
  const classes = makeStyles(styles, { name: 'FilterSidebar' })();
  const dispatch = useDispatch();

  const clients = useSelector(selectPartyClientsSorted);
  const isClientsLoading = useSelector(selectPartyClientLoading);
  const products = useSelector(selectProductsSorted);
  const filters = useSelector(selectRiskFilters);
  const filterIsOpen = useSelector((state) => state.risk.filterIsOpen);

  const numberOfFilters = filters ? Object.keys(filters).filter((key) => !isEmpty(filters[key])).length : 0;

  useEffect(
    () => {
      let isSubscribed = true;
      if (isSubscribed && utils.generic.isInvalidOrEmptyArray(clients) && !isClientsLoading) {
        dispatch(getClients({ size: 1000 }));
      }
      // cleanup
      return () => {
        isSubscribed = false;
      };
    },
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );

  const handleOpenFilter = () => {
    dispatch(setRiskFilterStatus(true));
  };

  const handleCloseFilter = () => {
    dispatch(setRiskFilterStatus(false));
  };

  const handleResetFilter = () => {
    dispatch(setRiskFilters(initialState));
  };

  const handleValueChange = (value, key) => {
    const newFilters = { ...filters, [key]: value };
    !isEqual(filters, newFilters) && dispatch(setRiskFilters(newFilters));
  };

  const BadgeIcons = ({ disabled }) => {
    return (
      <Badge badgeContent={disabled ? 0 : numberOfFilters} compact type="primary">
        <FilterListIcon />
      </Badge>
    );
  };

  return (
    <>
      <IconButton
        data-testid="button-filter-with-sidebar"
        disableRipple
        size={size}
        color="inherit"
        onClick={handleOpenFilter}
        disabled={disabled}
      >
        <BadgeIcons disabled={disabled} />
      </IconButton>

      <Drawer
        anchor="right"
        style={{
          width: '400px',
        }}
        open={filterIsOpen}
        onClose={handleCloseFilter}
        data-testid="drawer-filter-with-sidebar"
        BackdropProps={{ invisible: true }}
      >
        <Box
          position="relative"
          display="flex"
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          classes={{ root: classes.filterTop }}
        >
          <Typography variant="subtitle1" classes={{ root: classes.filterTitle }}>
            {utils.string.t('products.filter.title')}
          </Typography>
          <IconButton data-testid="close-button-filter-sidebar" onClick={handleCloseFilter}>
            <CloseIcon width={20} height={20} />
          </IconButton>
        </Box>
        <Divider />
        <Box classes={{ root: classes.filterContainer }}>
          {products?.length > 1 ? (
            <>
              <Box sx={{ px: 2, py: 2 }} position="relative">
                <CustomAutocompleteMui
                  title={utils.string.t('products.filter.productsTitle')}
                  optionsSearchText={utils.string.t('products.filter.productsOptionText')}
                  handleValueChange={handleValueChange}
                  selectionKey="products"
                  selectedOptions={filters?.products}
                  options={products || []}
                />
              </Box>
              <Divider />
            </>
          ) : null}
          {clients?.length > 1 ? (
            <>
              <Box sx={{ px: 2, py: 2 }} position="relative">
                <CustomAutocompleteMui
                  title={utils.string.t('products.filter.clientsTitle')}
                  optionsSearchText={utils.string.t('products.filter.clientOptionText')}
                  handleValueChange={handleValueChange}
                  selectionKey="clients"
                  selectedOptions={filters?.clients}
                  options={clients || []}
                  optionKey="value"
                  optionLabel="name"
                />
              </Box>
              <Divider />
            </>
          ) : null}
          <Box sx={{ px: 2, py: 2 }} position="relative">
            <FilterDateRange
              title={utils.string.t('products.filter.inceptionDateTitle')}
              handleOnChange={handleValueChange}
              selectionKey="inceptionDateRange"
              selection={filters?.inceptionDateRange}
            />
          </Box>
          <Divider />
          <Box sx={{ px: 2, py: 2 }} position="relative">
            <FilterDateRange
              title={utils.string.t('products.filter.expiryDateTitle')}
              handleOnChange={handleValueChange}
              selectionKey="expiryDateRange"
              selection={filters?.expiryDateRange}
            />
          </Box>
          <Divider />
        </Box>

        <Box
          position="absolute"
          left={0}
          right={0}
          bottom={0}
          display="flex"
          justifyContent="flex-end"
          classes={{ root: classes.filterFooter }}
        >
          <Button size="medium" color="default" variant="outlined" onClick={handleResetFilter}>
            {utils.string.t('products.filter.clearAll')}
          </Button>
        </Box>
      </Drawer>
    </>
  );
}
