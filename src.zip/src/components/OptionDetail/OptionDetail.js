import React from 'react';

import { OptionDetailView } from './OptionDetail.view';

export function OptionDetail(props) {
  return <OptionDetailView {...props} />;
}

export default OptionDetail;
