import React from 'react';

// app
import { FormHiddenView } from './FormHidden.view';

export default function FormText(props) {
  return <FormHiddenView {...props} />;
}
