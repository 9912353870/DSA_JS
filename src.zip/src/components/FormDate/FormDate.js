import React from 'react';

// app
import { FormDateView } from './FormDate.view';

export default function FormDate(props) {
  return <FormDateView {...props} />;
}
