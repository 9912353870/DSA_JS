import { useState } from 'react';
import config from 'config';

export const EdgeImage = ({ container, imageName, alt, width, height, ...props }) => {
  const [error, setError] = useState(false);

  const iconUrl = `${config.assets}/${container}/${imageName}`;

  const onError = () => {
    setError(true);
  };

  return error ? null : <img src={iconUrl} alt={alt} width={width} height={height} {...props} onError={onError} />;
};
