import React from 'react';
import PropTypes from 'prop-types';
import { CircularProgressWithLabelView } from './CircularProgressWithLabel.view';

CircularProgressWithLabel.propTypes = {
  progress: PropTypes.number.isRequired,
};

export default function CircularProgressWithLabel(props) {
  return <CircularProgressWithLabelView progress={props.progress} />;
}
