import React from 'react';
import { render } from 'tests';
import { DateRange } from '../DateRange';

describe('COMPONENTS › Calendar › DateRange', () => {
  const handleOnChange = jest.fn();

  it('renders without crashing', () => {
    const { container } = render(<DateRange handleOnChange={handleOnChange} />);

    // assert
    expect(container).toBeInTheDocument();
  });
});
