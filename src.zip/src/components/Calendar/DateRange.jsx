import { useState } from 'react';

import { DateRangePicker } from 'react-date-range';

import { defaultStaticRanges } from './defaultRanges';
import 'react-date-range/dist/styles.css'; // main css file
import './default.css'; // theme css file

import { FILTER_MIN_DATE, FILTER_MAX_DATE } from 'consts';

export const DateRange = ({ displayMonths, handleOnChange }) => {
  const [state, setState] = useState({
    selection: {
      startDate: new Date(),
      endDate: new Date(),
      key: 'selection',
    },
  });

  const handleSelect = (ranges) => {
    const newRanges = {
      ...ranges,
      selection: {
        ...ranges?.selection,
        startDate: ranges?.selection?.startDate?.setHours ? ranges.selection.startDate?.setHours(0, 0, 0, 0) : ranges.selection.startDate,
        endDate: ranges?.selection?.endDate?.setHours ? ranges.selection.endDate?.setHours(23, 59, 59, 999) : ranges.selection.endDate,
      },
    };

    handleOnChange(newRanges);
    setState({ ...state, ...newRanges });
  };

  return (
    <DateRangePicker
      onChange={handleSelect}
      months={displayMonths || 1}
      direction="vertical"
      scroll={{ enabled: true }}
      ranges={[state.selection]}
      inputRanges={[]}
      staticRanges={defaultStaticRanges}
      rangeColors={['#334762']}
      minDate={FILTER_MIN_DATE}
      maxDate={FILTER_MAX_DATE}
    />
  );
};
