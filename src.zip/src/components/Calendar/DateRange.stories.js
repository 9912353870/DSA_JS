import { withKnobs } from '@storybook/addon-knobs';
import { DateRange } from 'components';

export default {
  title: 'Calendar',
  decorators: [withKnobs],
};

const handleDateChange = (date) => {
  alert(JSON.stringify(date));
};

export const CalendarDateRange = () => {
  return <DateRange handleOnChange={handleDateChange} />;
};
