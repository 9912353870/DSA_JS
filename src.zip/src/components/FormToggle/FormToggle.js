import React from 'react';

// app
import { FormToggleView } from './FormToggle.view';

export default function FormToggle(props) {
  return <FormToggleView {...props} />;
}
