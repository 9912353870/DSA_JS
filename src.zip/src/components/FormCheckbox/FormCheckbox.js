import React from 'react';

// app
import { FormCheckboxView } from './FormCheckbox.view';

export default function FormCheckbox(props) {
  return <FormCheckboxView {...props} />;
}
