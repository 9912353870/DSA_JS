import React from 'react';
import '@testing-library/jest-dom/extend-expect';

// app
import Logo from './Logo';
import { render } from 'tests';

describe('COMPONENTS › Logo', () => {
  describe('@render', () => {
    it("renders logo if brand isn't defined", () => {
      // arrange
      const { getByText } = render(<Logo />);

      // assert
      expect(getByText('Edge_Solo.svg')).toBeInTheDocument();
    });

    it('renders Edge Solo logo if brand is set to "ardonagh_specialty"', () => {
      // arrange
      const { getByText } = render(<Logo />, { initialState: { ui: { brand: 'ardonagh_specialty' } } });

      // assert
      expect(getByText('Edge_Solo.svg')).toBeInTheDocument();
    });

    it('renders Edge Solo logo if brand is set to "priceforbes"', () => {
      // arrange
      const { getByText } = render(<Logo />, { initialState: { ui: { brand: 'priceforbes' } } });

      // assert
      expect(getByText('Edge_Solo.svg')).toBeInTheDocument();
    });

    it('renders Edge Solo logo if brand is set to "bishopsgate"', () => {
      // arrange
      const { getByText } = render(<Logo />, { initialState: { ui: { brand: 'bishopsgate' } } });

      // assert
      expect(getByText('Edge_Solo.svg')).toBeInTheDocument();
    });
  });
});
