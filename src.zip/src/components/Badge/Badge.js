import React from 'react';

// app
import { BadgeView } from './Badge.view';

export default function Badge(props) {
  return <BadgeView {...props} />;
}
