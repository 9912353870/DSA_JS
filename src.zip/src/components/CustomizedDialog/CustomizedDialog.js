import { React, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router';
import classnames from 'classnames';

// app
import styles from './CustomizedDialog.styles';
import { Button, Translate } from 'components';
import { selectDmsWidgetExpanded } from 'stores';
import * as constants from 'consts';
import config from 'config';

// mui
import { makeStyles, Dialog, DialogTitle, DialogContent, Divider } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import CloseIcon from '@material-ui/icons/Close';
import FullscreenIcon from '@material-ui/icons/Fullscreen';


CustomizedDialog.propTypes = {
  dialogOpen: PropTypes.bool.isRequired,
  modalTitle: PropTypes.string.isRequired,
  isDirty: PropTypes.bool.isRequired,
  redirectUrl: PropTypes.string.isRequired,
  isFullScreen: PropTypes.bool.isRequired,
  handlers: PropTypes.shape({
    handleDialogClose: PropTypes.func.isRequired,
    handleCleanUp: PropTypes.func,
    handleFullScreenMode: PropTypes.func,
  }),
};

CustomizedDialog.defaultProps = {
  handlers: {
    handleCleanUp: () => { },
    handleFullScreenMode: () => { }
  },
  isFullScreen: true,
};

function CustomizedDialog({ dialogOpen, modalTitle, isDirty, redirectUrl, isFullScreen, parentRef, handlers, children }) {
  const classes = makeStyles(styles, { name: 'CustomizedDialog' })();
  const history = useHistory();

  const [openDialog, setOpenDialog] = useState(false);
  const [fullScreenMode, setfullScreenMode] = useState(isFullScreen)

  const isDmsWidgetExpanded = useSelector(selectDmsWidgetExpanded);

  useEffect(() => {
    setOpenDialog(dialogOpen);
  }, [dialogOpen]);

  const handleClose = (event, reason) => {
    if (reason === constants.MODAL_BACKDROP_CLICK) {
      return;
    } else if (isDirty) {
      handlers.handleDialogClose();
    } else {
      handlers.handleCleanUp();
      setOpenDialog(false);
      history.push(redirectUrl || config.routes.claimsFNOL.root);
    }
  };
  const handleFullScreen = () => {
    setfullScreenMode(!fullScreenMode)
    handlers.handleFullScreenMode(!fullScreenMode)
  }
  return (

    <Dialog
      fullScreen={fullScreenMode}
      maxWidth="xl"
      className={classnames({
        [classes.contentShift]: isDmsWidgetExpanded,
        [classes.dialogExpanded]: isDmsWidgetExpanded,
        [classes.dialog]: !isDmsWidgetExpanded
      })}
      fullWidth
      onClose={handleClose}
      aria-labelledby="customized-dialog-title"
      open={openDialog}
      disablePortal
      container={() => parentRef.current}
    >
      <Button
        icon={FullscreenIcon}
        variant="text"
        onClick={handleFullScreen}
        nestedClasses={{ btn: classes.fullScreen }}
        data-testid="modal-fullscreen-button"
      />
      <Button icon={CloseIcon} variant="text" onClick={handleClose} nestedClasses={{ btn: classes.close }} />

      <DialogTitle disableTypography>
        <Translate label={modalTitle} variant="h2" className={classes.title} />
      </DialogTitle>
      <Divider />
      <DialogContent className={classes.content}>
        <div className={classes.container}>{children}</div>
      </DialogContent>
    </Dialog>
  );
}

export default withStyles(styles)(CustomizedDialog);
