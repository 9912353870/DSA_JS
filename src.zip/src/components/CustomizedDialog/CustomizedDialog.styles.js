const styles = (theme) => ({
  dialog: {
    marginRight: theme.mixins.drawer.width.collapsed / 2,
    transition: theme.transitions.create(['margin'], {
      duration: 800,
    }),
  },
  dialogExpanded: {
    marginRight: theme.mixins.drawer.width.expanded.xs,
    transition: theme.transitions.create(['margin'], {
      duration: 800,
    }),

    [theme.breakpoints.up('sm')]: {
      marginRight: theme.mixins.drawer.width.expanded.sm,
    },

    [theme.breakpoints.up('md')]: {
      marginRight: theme.mixins.drawer.width.expanded.md,
    },

    [theme.breakpoints.up('lg')]: {
      width: `calc(100% - ${theme.mixins.drawer.width.expanded.lg + 180}px)`,
      marginRight: `calc(180px +  ${theme.mixins.drawer.width.expanded.lg}px)`,
    },
  },
  title: {
    marginBottom: 0,
  },
  subtitle: {
    marginBottom: 0,
  },
  close: {
    position: 'absolute',
    top: 11,
    right: 11,
  },
  content: {
    display: 'flex',
    flexDirection: 'column',
    overflow: 'auto',
  },
  container: {
    flex: 1,
    flexDirection: 'column',
    display: 'flex',
    marginTop: 0,
    minHeight: 150,
    width: '100%',
  },
  fullScreen: {
    position: 'absolute',
    top: 11,
    right: 40,
  },
});

export default styles;
