/* eslint-disable no-use-before-define */
import * as React from 'react';
import PropTypes from 'prop-types';
import parse from 'autosuggest-highlight/parse';
import match from 'autosuggest-highlight/match';

import { makeStyles } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import Popper from '@material-ui/core/Popper';
import List from '@material-ui/core/List';
import Slide from '@material-ui/core/Slide';
import SearchIcon from '@material-ui/icons/Search';
import CloseIcon from '@material-ui/icons/Close';
import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';
import Typography from '@material-ui/core/Typography';
import Autocomplete from '@material-ui/lab/Autocomplete';
import ButtonBase from '@material-ui/core/ButtonBase';
import InputBase from '@material-ui/core/InputBase';

import * as utils from 'utils';
import { styles } from './CustomAutocompleteMui.styles';

CustomAutocompleteMui.propTypes = {
  title: PropTypes.string.isRequired,
  noOptionsText: PropTypes.string,
  optionsSearchText: PropTypes.string.isRequired,
  options: PropTypes.array.isRequired,
  optionKey: PropTypes.string.isRequired,
  optionLabel: PropTypes.string.isRequired,
};

CustomAutocompleteMui.defaultProps = {
  muiComponentProps: {},
  options: [],
  optionKey: 'value',
  optionLabel: 'label',
  value: null,
  defaultValue: null,
};

export default function CustomAutocompleteMui({
  selectionKey,
  title,
  noOptionsText,
  optionsSearchText,
  options,
  optionKey,
  optionLabel,
  handleValueChange,
  selectedOptions = [],
}) {
  const classes = makeStyles(styles, { name: 'CustomAutocompleteMui' })();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [value, setValue] = React.useState(selectedOptions);
  const [pendingValue, setPendingValue] = React.useState([]);

  const handleClick = (event) => {
    setPendingValue(value);
    setAnchorEl(event.currentTarget);
  };

  const removeValue = (index) => {
    const newValue = [...value];
    newValue.splice(index, 1);
    setValue(newValue);
    handleValueChange(newValue, selectionKey);
  };

  const removeAllValues = () => {
    handleValueChange([], selectionKey);
    setValue([]);
  };

  const handleClose = (event, reason) => {
    if (reason === 'toggleInput') {
      return;
    }
    setValue(pendingValue);
    handleValueChange(pendingValue, selectionKey);
    if (anchorEl) {
      anchorEl.focus();
    }
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? 'github-label' : undefined;

  const SelectedOption = ({ label, index, removeValue }) => {
    const [isActive, setIsActive] = React.useState(false);

    const handleMouseEnter = () => {
      setIsActive(true);
    };

    const handleMouseLeave = () => {
      setIsActive(false);
    };

    return (
      <div
        className={classes.selectedOption}
        onClick={() => removeValue(index)}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <span className={classes.text}>{label}</span>
        <Slide direction="left" in={isActive} mountOnEnter unmountOnExit>
          <RemoveCircleIcon className={classes.remove} />
        </Slide>
      </div>
    );
  };

  return (
    <React.Fragment>
      <div data-testid="custom-autocomplete-root" className={classes.root}>
        <ButtonBase
          data-testid="custom-autocomplete-button"
          disableRipple
          className={classes.button}
          aria-describedby={id}
          onClick={handleClick}
        >
          <Typography variant="body2">{title}</Typography>
          <SearchIcon />
        </ButtonBase>
        {value.map((label, index) => (
          <SelectedOption key={label[optionKey]} removeValue={removeValue} index={index} label={label[optionLabel]} />
        ))}
        {value?.length ? (
          <div
            style={{
              width: '100%',
              textAlign: 'right',
            }}
          >
            <span onClick={removeAllValues} className={classes.clear}>
              {utils.string.t('products.filter.clear')}
            </span>
          </div>
        ) : null}
      </div>
      <Popper id={id} open={open} anchorEl={anchorEl} placement="bottom" disablePortal={true} className={classes.popper}>
        <div className={classes.header}>
          <span>{optionsSearchText}</span>
          <IconButton data-testid="close-custom-autocomplete-popper" onClick={handleClose} size="small" disableRipple>
            <CloseIcon width={16} height={16} />
          </IconButton>
        </div>
        <Autocomplete
          open
          onClose={handleClose}
          multiple
          classes={{
            paper: classes.paper,
            option: classes.option,
            selected: classes.selected,
            popperDisablePortal: classes.popperDisablePortal,
          }}
          value={pendingValue}
          onChange={(event, newValue) => {
            setPendingValue(newValue);
          }}
          disableCloseOnSelect
          disablePortal
          noOptionsText={noOptionsText || utils.string.t('products.filter.noResults')}
          ListboxComponent={List}
          renderOption={(option, { inputValue }) => {
            const title = option[optionLabel];
            const matches = match(title, inputValue);
            const parts = parse(title, matches);

            return (
              <React.Fragment>
                <div className={classes.text} data-testid={`option-${title}`}>
                  {parts.map((part, index) => (
                    <span key={index} style={{ fontWeight: part.highlight ? 700 : 400 }}>
                      {part.text}
                    </span>
                  ))}
                </div>
              </React.Fragment>
            );
          }}
          options={[...options].sort((a, b) => {
            // Display the selected labels first.
            let ai = value.indexOf(a);
            ai = ai === -1 ? value.length + options.indexOf(a) : ai;
            let bi = value.indexOf(b);
            bi = bi === -1 ? value.length + options.indexOf(b) : bi;
            return ai - bi;
          })}
          getOptionLabel={(option) => option[optionLabel]}
          renderInput={(params) => (
            <InputBase
              data-testid="custom-autocomplete-input"
              ref={params.InputProps.ref}
              inputProps={params.inputProps}
              autoFocus
              className={classes.inputBase}
            />
          )}
        />
      </Popper>
    </React.Fragment>
  );
}
