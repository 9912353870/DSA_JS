import { render, screen } from 'tests';
import userEvent from '@testing-library/user-event';
// app
import CustomAutocompleteMui from './CustomAutocompleteMui';

describe('COMPONENTS › CustomAutocompleteMui', () => {
  const options = [
    {
      value: 'chocolate',
      label: 'Chocolate',
    },
    {
      value: 'strawberry',
      label: 'Strawberry',
    },
    {
      value: 'vanilla',
      label: 'Vanilla',
    },
  ];

  const handleValueChange = jest.fn();

  it('renders without crashing', () => {
    // arrange
    render(
      <CustomAutocompleteMui
        options={options}
        title="Custom Autocomplete"
        noOptionsText="No Options Text"
        optionsSearchText="Options Search Text"
        selectionKey="selectionKey"
        handleValueChange={handleValueChange}
      />
    );

    // assert
    expect(screen.getByTestId('custom-autocomplete-root')).toBeInTheDocument();
    expect(screen.getByText('Custom Autocomplete')).toBeInTheDocument();
    expect(screen.queryByText('products.filter.clear')).not.toBeInTheDocument();
    userEvent.click(screen.getByTestId('custom-autocomplete-button'));

    expect(screen.getByText('Options Search Text')).toBeInTheDocument();
    expect(screen.getByText('Chocolate')).toBeInTheDocument();
    expect(screen.getByText('Strawberry')).toBeInTheDocument();
    expect(screen.getByText('Vanilla')).toBeInTheDocument();

    userEvent.click(screen.getByText('Chocolate'));
    userEvent.click(screen.getByText('Vanilla'));

    userEvent.click(screen.getByTestId('close-custom-autocomplete-popper'));
    expect(handleValueChange).toHaveBeenCalledTimes(1);
    expect(screen.queryByText('Options Search Text')).not.toBeInTheDocument();
    expect(screen.getByText('Chocolate')).toBeInTheDocument();
    expect(screen.queryByText('Strawberry')).not.toBeInTheDocument();
    expect(screen.getByText('Vanilla')).toBeInTheDocument();
    expect(screen.getByText('products.filter.clear')).toBeInTheDocument();
    userEvent.click(screen.getByText('Vanilla'));
    expect(screen.queryByText('Vanilla')).not.toBeInTheDocument();

    userEvent.click(screen.getByText('products.filter.clear'));
    expect(handleValueChange).toHaveBeenCalledWith([], 'selectionKey');
    expect(screen.queryByText('Chocolate')).not.toBeInTheDocument();
  });

  it('renders with selected options', () => {
    // arrange
    render(
      <CustomAutocompleteMui
        options={options}
        title="Custom Autocomplete"
        noOptionsText="No Options Text"
        optionsSearchText="Options Search Text"
        selectionKey="selectionKey"
        selectedOptions={[options[0], options[1]]}
        handleValueChange={handleValueChange}
      />
    );
    // assert
    expect(screen.getByTestId('custom-autocomplete-root')).toBeInTheDocument();
    expect(screen.getByText('Custom Autocomplete')).toBeInTheDocument();

    expect(screen.getByText(options[0].label)).toBeInTheDocument();
    expect(screen.getByText(options[1].label)).toBeInTheDocument();
    expect(screen.getByText('products.filter.clear')).toBeInTheDocument();
  });

  it('Autocomplete filters options on search', () => {
    // arrange
    render(
      <CustomAutocompleteMui
        options={options}
        title="Custom Autocomplete"
        noOptionsText="No Options Text"
        optionsSearchText="Options Search Text"
        selectionKey="selectionKey"
        handleValueChange={handleValueChange}
      />
    );

    // assert
    expect(screen.getByTestId('custom-autocomplete-root')).toBeInTheDocument();
    expect(screen.getByText('Custom Autocomplete')).toBeInTheDocument();
    expect(screen.queryByText('products.filter.clear')).not.toBeInTheDocument();
    userEvent.click(screen.getByTestId('custom-autocomplete-button'));
    userEvent.type(screen.getByTestId('custom-autocomplete-input'), 'ch');
    expect(screen.getByTestId('option-Chocolate')).toBeInTheDocument();
    expect(screen.queryByTestId('option-Strawberry')).not.toBeInTheDocument();
    expect(screen.queryByTestId('option-Vanilla')).not.toBeInTheDocument();
  });
});
