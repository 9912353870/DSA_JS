import { CustomAutocompleteMui } from 'components';
import { withKnobs, text } from '@storybook/addon-knobs';
import { Box } from '@material-ui/core';

export default {
  title: 'Custom Autocomplete Mui',
  component: CustomAutocompleteMui,
  decorators: [withKnobs],
};

const options = [
  {
    value: 'chocolate',
    label: 'Chocolate',
  },
  {
    value: 'strawberry',
    label: 'Strawberry',
  },
  {
    value: 'vanilla',
    label: 'Vanilla',
  },
];

const handleValueChange = (value, selectionKey) => {
  console.log(value, selectionKey);
};

export const Default = () => {
  return (
    <Box style={{ minWidth: 200 }}>
      <CustomAutocompleteMui
        title={text('Title', 'Custom Autocomplete')}
        noOptionsText={text('No Options Text', 'No Options Text')}
        optionsSearchText={text('Options Search Text', 'Options Search Text')}
        selectionKey="selectionKey"
        options={options}
        handleValueChange={handleValueChange}
      />
    </Box>
  );
};

export const WithSelectedOptions = () => {
  return (
    <Box style={{ minWidth: 250 }}>
      <CustomAutocompleteMui
        title={text('Title', 'Custom Autocomplete')}
        noOptionsText={text('No Options Text', 'No Options Text')}
        optionsSearchText={text('Options Search Text', 'Options Search Text')}
        selectionKey="selectionKey"
        options={options}
        selectedOptions={[options[0], options[1]]}
        handleValueChange={handleValueChange}
      />
    </Box>
  );
};
