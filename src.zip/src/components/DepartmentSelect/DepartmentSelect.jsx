import { useDispatch, useSelector } from 'react-redux';
import get from 'lodash/get';
import { makeStyles, Box, Typography } from '@material-ui/core';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';

import { setDepartmentSelected, selectUserDepartment } from 'stores';
import { PopoverMenu } from 'components';
import * as utils from 'utils';
import { PLACEMENT_SOURCE } from 'consts';

const useStyles = makeStyles((theme) => ({
  logoBox: {
    width: 120,
  },
  logo: {
    width: '100%',
    height: '100%',
    objectFit: 'contain',
  },
  navBox: {
    margin: '0 20px',
    height: '100%',
  },
}));

export const DepartmentSelect = ({ onDepartmentChange }) => {
  const classes = useStyles();
  const dispatch = useDispatch();

  const user = useSelector((state) => state.user);
  const userDepartment = useSelector(selectUserDepartment) || {};
  const referenceDataDepartments = useSelector((state) => get(state, 'referenceData.departments'));
  const departmentList = utils.user.department.getAll(user);
  const deptSelected = userDepartment;

  const deptItemsFiltered = departmentList
    ?.map((deptId) => {
      const department = utils.referenceData.departments.getById(referenceDataDepartments, deptId) || {};
      if (!deptId || !department.name) return null;

      return {
        id: deptId,
        label: department.name,
        callback: () => {
          dispatch(setDepartmentSelected(deptId));
          if (utils.generic.isFunction(onDepartmentChange)) onDepartmentChange(deptId, department.name);
        },
      };
    })
    .filter((dept) => dept);

  const departmentSelect = (
    <PopoverMenu
      id="department-select"
      text={deptSelected.name || ''}
      size="medium"
      items={deptItemsFiltered}
      icon={ArrowDropDownIcon}
      iconPosition="right"
      nestedClasses={{ label: { fontWeight: 600 } }}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
    />
  );

  return (
    <Box display="flex" alignItems="center" justifyContent="flex-start">
      {PLACEMENT_SOURCE.logo ? (
        <Box className={classes.logoBox}>
          <img src={PLACEMENT_SOURCE.logo} alt={PLACEMENT_SOURCE.company} className={classes.logo} />
        </Box>
      ) : null}
      <Box display="flex" alignItems="center" justifyContent="flex-start">
        <Box display="flex" alignItems="center" className={classes.navBox}>
          <NavigateNextIcon fontSize="small" />
        </Box>
        <Typography variant="body1">{PLACEMENT_SOURCE.gxbInstance}</Typography>
        <Box display="flex" alignItems="center" className={classes.navBox}>
          <NavigateNextIcon fontSize="small" />
        </Box>
        <Typography variant="body1">{departmentSelect}</Typography>
      </Box>
    </Box>
  );
};
