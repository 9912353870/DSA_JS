const styles = (theme) => ({
  form: {
    marginTop: theme.spacing(2.5),
  },
  divider: {
    marginBottom: theme.spacing(3),
  },
});

export default styles;
