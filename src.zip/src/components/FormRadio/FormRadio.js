import React from 'react';

// app
import { FormRadioView } from './FormRadio.view';

export default function FormRadio(props) {
  return <FormRadioView {...props} />;
}
