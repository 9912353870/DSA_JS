import React from 'react';

// app
import { EmptyView } from './Empty.view';

export default function Empty(props) {
  return <EmptyView {...props} />;
}
